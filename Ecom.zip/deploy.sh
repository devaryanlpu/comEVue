#!/bin/sh

cd /home/heyads/www-hillsflatlumber
rm -rf public-site
cp -R dist public-site
cp .htaccess public-site/
