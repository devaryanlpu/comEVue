<template>
  <button class="filter-item mr-2 mb-1">
    {{ filterVal }}
    <icon name="times" class="ml-1"></icon>
  </button>
</template>

<script>
export default {
  name: "FilterItem",
  props: [
    'filterVal'
  ],
};
</script>

<style>
  .filter-item {
    display: inline-block;
    background-color: #f2f2f2;
    border-radius: 8px;
    font-size: 13px;
    color: #575757;
    font-family: 'Helvetica Neue'
  }
</style>

