<template>
  <div class="social-connect" v-if="connect">
    <h5>Connect</h5>
    <div id="social">
        <a :href="connect.facebook_link" target="_blank" v-if="connect.facebook_link">
        <img src="/icons/facebook.svg" alt="Facebook" class="img-fluid">
        </a>
        <a :href="connect.twitter_link" target="_blank" v-if="connect.twitter_link">
        <img src="/icons/twitter.svg" alt="Twitter" class="img-fluid">
        </a>
        <a :href="connect.instagram_link" target="_blank" v-if="connect.instagram_link">
        <img src="/icons/instagram.svg" alt="Instagram" class="img-fluid">
        </a>
        <a :href="connect.youtube_link" target="_blank" class="mr-0" v-if="connect.youtube_link">
        <img src="/icons/youtube.svg" alt="Youtube" class="img-fluid">
        </a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Connect',
  props: ['connect'],
};
</script>