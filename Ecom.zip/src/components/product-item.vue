<template>
  <div class="card card-primary discounted-item" @click="goToDetailsPage(item)">
    <div class="card-body p-0">
      <div class="product">
        <div v-if="!editable" class="add-to-card" @click.stop="openQtyModal">
          <span v-if="quantity > 0">
            {{ quantity }}
          </span>
          <img v-else src="/icons/add-to-cart.svg">
        </div>
        <div class="edit-product" v-else>
          <a><img src="/images/edit.png"></a>
          <a><img src="/images/remove.png"></a>
        </div>
        <span v-if="item.promo_price" class="badge badge-danger">
          <span>SPECIAL</span>${{ item.promo_price }}
        </span>
        <div v-if="!loaded" class="loader-wrapper">
          <img src="/icons/loader.gif" class="loader">
        </div>
        <img
          :src="internalApi ? item.image : item.image_url"
          :alt="item.title | lowerCase"
          @load="loaded = true"
          :class="{ 'd-none': !loaded }"
          class="product-image img-fluid">
        <h6>{{ item.title | lowerCase }}</h6>
        <div class="info">
          <div class="standard-price">
            Reg. ${{ item.price | removeDecimals }}
          </div>
          <div v-if="businessDetails.show_stock_level" class="items-left text-danger">
            <template v-if="item.num_inventory >= 1 && item.num_inventory <= 5">
              <span>Only {{ item.num_inventory }} Left</span>
            </template>
            <template v-else>
              <template v-if="item.num_inventory <= 0">
                <span class="out-of-stock" v-if="!item.vendor_id || !businessDetails.show_oos_special">Out of Stock</span>
                <span v-else>Special Order</span>
              </template>
            </template>

          </div>
        </div>
      </div>
    </div>
    <div v-if="businessDetails.show_competitors"
         class="card-footer bg-white" :class="{ 'd-none': item.competitors && !item.competitors.length }">
      <img v-if="!item.competitors || !item.competitors.length" src="/icons/loader.gif" class="loader">
      <div v-if="item.competitors && item.competitors.length" class="compare d-flex">
          <div v-for="(competitor, index) in item.competitors" :key="`competitors-item-${item.id}-${index}`">
            <span>${{ competitor.price | removeDecimals }}</span>
            <img style="max-width:100%;" :src="competitor.logo">
          </div>
      </div>
    </div>
    <div v-if="overlayActive" class="overlay" @click="closeQtyModal">
      <div ref="qty" v-click-outside="closeQtyModal" class="btn-group" role="group">
        <button type="button" class="btn btn-white qty-minus" @click="updateQty(quantity - 1)"></button>
        <div class="input-group">
          <input v-model="quantity" type="text" class="form-control" min="1" readonly>
        </div>
        <button type="button" class="btn btn-white qty-plus" @click="updateQty(quantity + 1)"></button>
      </div>
    </div>
  </div>
</template>

<script>
  import CartApiService from '@/api-services/cart.service';

  export default {
    name: 'ProductItem',
    props: {
      item: {
        type: Object,
        default: null
      },
      internalApi: {
        type: Boolean,
        default: false
      },
      editable: {
        type: Boolean,
        default: false
      }
    },
    data: () => ({
      loaded: false,
      overlayActive: false,
      quantity: 0,
    }),
    mounted(){
        if(this.$store.state.cart.parcels){
          if(this.$store.state.cart.parcels[0]) {
              let items = this.$store.state.cart.parcels[0].items;
              //let self = this;
              [...items].forEach(item => {
                  if(item.sku == this.item.sku) {
                      this.quantity = item.quantity;
                  }
              });
          }
        }
    },
    computed: {
      cart() {
        return this.$store.state.cart;
      },
      preferences() {
        return this.$store.state.preferences;
      },
      businessDetails() {
        return this.$store.state.businessDetails;
      }
    },
    watch: {
      'cart': {
        handler() {
          const cartParcels = this.cart.parcels;
          if (cartParcels && cartParcels.length) {
              const pickupParcel = cartParcels.find(item => {
                  return item.type === 'pickup';
              });
              const specialParcels = cartParcels.filter(item => {
                  return item.type === 'special';
              });
              let specialItems = [];
              if (specialParcels && specialParcels.length) {
                  specialParcels.forEach(parcel => {
                      if (parcel.items && parcel.items.length) {
                          specialItems = [...specialItems, ...parcel.items];
                      }
                  });
              }
              let items;
              if ( pickupParcel ) {
                  items = [...specialItems, ...pickupParcel.items];
              } else {
                  items = specialItems;
              }
              let cartItem = items.find(x => x.store_product_id === this.item.id);
              if (cartItem && cartItem.quantity) {
              }
          }
        },
        deep: true
      }
    },
    methods: {
      urlFriendly(value) {
        return value.replace(/[ /]/g, '+');
      },
      goToDetailsPage(item) {
        this.$router.push({
          name: 'products-id',
          params: {
            id: item.sku,
            title: this.urlFriendly(item.title)
          }
        });
      },
      openQtyModal() {
        this.overlayActive = true;
        this.$store.state.addingToCart = true;
          if(this.quantity == 0) {
              this.quantity = 1;
          }

          console.log(this.quantity);
          CartApiService.addItem(this.item.store_product_id  || this.item.id, this.quantity)
          .then(() => {
            this.$store.dispatch("fetchCartItemsDetails");
            this.$store.state.addingToCart = false;
          })
          .catch(err => {
            console.log('error', err)
            alert('Out of stock!');
          });
      },
      closeQtyModal(event) {
        const path = event.path;

        event.stopPropagation();
        if (path.includes(this.$refs.qty)) return;

        this.overlayActive = false;
      },
      updateQty(value) {
        this.$store.state.addingToCart = true;
        this.quantity = value;
        if (value === 0) {
          this.overlayActive = false;
          CartApiService.removeItem(this.item.store_product_id || this.item.id)
            .then(() => {
              this.$store.dispatch("fetchCartItemsDetails");
              this.$store.state.addingToCart = false;
            });
        } else {
          CartApiService.addItem(this.item.store_product_id  || this.item.id, value)
          .then((res) => {
            if (res.status === 200) {
              this.$store.dispatch("fetchCartItemsDetails");
            } else if (res.status === 201) {
              alert('Out of stock!');
            }

              this.$store.state.addingToCart = false;
            })
            .catch((err) => {
              console.log('add to cart error', err.response);
            });
        }
      }
    },
    filters: {
      removeDecimals: function (value) {
        return Number(value).toString();
      },
      lowerCase: function(value) {
        return value.toLowerCase();
      }
    }
  };
</script>
<style lang="scss" scoped>
  .card {
    .card-body {
      .product {
        .edit-product {
          position: relative;
          top: -10px;
          left: 0;
          margin-left: 5px !important;

          a {
            margin: 0 3px;

            img {
              width: 25px;
              height: 25px;
            }
          }
        }
      }
    }
  }
</style>
