<template>
  <section>
    <div class="container">
      <div class="card card-primary mb-0">
        <div class="card-header d-flex justify-content-between bg-white">
          Favorite Products
        </div>
        <div class="card-body offer">
          <swiper ref="productsSlider" :options="swiperOptions" class="products-slider">
            <swiper-slide
              v-for="(item, index) in favouriteProducts"
              :key="'favourite-products-' + index">
              <product-item :item="item" :internal-api="false"/>
            </swiper-slide>
          </swiper>
          <div class="swiper-button-prev product-swiper-prev" slot="button-prev">
            <div class="swipe-prev" @click="swiper.slidePrev()" />
          </div>
          <div class="swiper-button-next product-swiper-next" slot="button-next">
            <div class="swipe-next" @click="swiper.slideNext()" />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>


<script>

import ProductApiService from '@/api-services/product.service';

export default {
  name: 'FacouriteProductsSection',
  props: ['type'],
  data: () => ({
    swiperOptions: {
      loop: false,
      slidesPerView: 'auto',
      centeredSlides: false,
      spaceBetween: 10,
      draggable: true,
      allowTouchMove: true,
      watchOverflow: true,
      navigation: {
        nextEl: '.product-swiper-next',
        prevEl: '.product-swiper-prev'
      }
    }
  }),
  computed: {
    options() {
      return this.$store.state.homepage.find(x => x.widget_type === this.type);
    },
    swiper() {
      return this.$refs.productsSlider.swiper;
    },
    favouriteProducts() {
      return this.$store.state.favouriteProducts;
    }
  },
  async mounted() {
    if (!this.favouriteProducts) {
      ProductApiService.getFavouriteProducts().then(response => {
        let allProducts = [];

        response.data.data.forEach(item => {
          item.competitors = null;
          item.similars = null;
          item.videos = null;

          allProducts.push(item);
        });

        this.$store.commit('addProductsRange', allProducts);
        this.$store.commit('setFavouriteProducts', allProducts);

        let allSKUs = [];
        allProducts.forEach(item => {
          allSKUs.push(item.sku);
        });

        if (allSKUs.length) {
          ProductApiService.getCompetitorsForSKUList(allSKUs).then(
            response => {
              this.$store.commit('setMultiCompetitors', response.data.data);
            }
          );
        }
        this.swiper.swiper
      });
    }
  }
};
</script>

<style lang="scss" scoped>
  .swiper-slide {
    width: auto !important;
    height: 340px;
  }
  .swiper-button-disabled {
    opacity: 0;
  }
  @media (max-width: 620px) {
    .offer {
      /*padding-right: 40px !important;
      padding-left: 40px !important;*/
    }
    .products-slider {
      padding-right: 20px;
    }
    .products-slider.swiper-container + .swiper-button-prev {
      left: 0;
      //top: 22px;
      //height: 100%;
      > .swipe-prev {
        //height: 100%;
      }
    }
    .products-slider.swiper-container ~ .swiper-button-next {
      right: 0;
      //top: 22px;
      //height: 100%;
      > .swipe-next {
        //height: 100%;
      }
    }
  }
</style>
