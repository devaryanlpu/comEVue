<template>
  <section class="subscribe d-flex" >
    <div class="container" :style="{backgroundImage: `url(/images/subscription-image.png)`, backgroundColor: `#E7EAEF !important`}">
      <div class="row d-flex align-items-center h-100">
        <div class="col-md-6">

        </div>
        <div class="col-md-6 d-flex align-items-center">
          <div id="flash-deal">
            <h1>{{ options.title }}</h1>
            <h2>{{ options.subtitle | uppercase }}</h2>
            <div class="d-flex flex-column flex-md-row mt-3">
              <input id="subscriberEmail" v-model="subscriberEmail" type="text" class="form-control" placeholder="Enter Email" @keypress.enter="subscribe">
              <button type="button" class="btn btn-secondary ml-md-2 mt-2 mt-md-0" @click="subscribe">Submit</button>
            </div>
            <small id="subscriberEmailSuccess" ref="subscriberEmailSuccess" class="d-none form-text">
              Successfully subscribed!
            </small>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import SubscriberApiService from '@/api-services/subscriber.service';

export default {
  name: 'SubscribeSection',
  filters: {
    uppercase(value) {
      return value ? value.toUpperCase() : '';
    }
  },
  data: () => ({
    subscriberEmail: null
  }),
  computed: {
    options() {
      let subscribeSection = this.$store.state.homepage.find(x => x.widget_type === '3');
      return subscribeSection.data;
    }
  },
  methods: {
    subscribe() {
      let target = this.$refs.subscriberEmailSuccess;
      target.classList.add('d-none');
      target.classList.remove('error');

      if (!this.subscriberEmail) return;

      SubscriberApiService.subscribe(this.subscriberEmail)
        .then((response) => {
          this.carouselSlides = response.data.data;
          target.classList.remove('d-none');
          target.innerText = 'Successfully subscribed!';
        })
        .catch((error) => {
          console.log('error in subscribe: ', error.response);
          target.classList.remove('d-none');
          target.classList.add('error');
          const errorResponse = error.response && error.response.data && error.response.data.errors;
          if (errorResponse['email'] && errorResponse['email'].length
            && errorResponse['email'][0] === 'The email has already been taken.') {
            target.innerText = 'This email has already been submitted.';
          } else {
            target.innerText = 'Something went wrong, please try again later.';
          }

        });
    }
  }
};
</script>

<style scoped>
section {
  margin: 30px 0;
}
.subscribe {
  height: 450px;
  background-repeat: no-repeat;
  background-size: contain;
}
#flash-deal {
  width: 100%;
}
</style>
