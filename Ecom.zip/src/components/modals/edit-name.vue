<template>
  <b-modal class="modal-box" ref="nameModal">
    <div slot="modal-header">
      <h5>Edit Name</h5>
      <span @click="hideModal">&times;</span>
    </div>
    <div class="d-block">
      First Name*
      <b-input
        v-model="firstName"
        placeholder="Enter your first name"
      >
      </b-input>
    </div>
    <div class="d-block">
      Last Name*
      <b-input
        v-model="lastName"
        placeholder="Enter your last name"
      >
      </b-input>
    </div>
    <div slot="modal-footer">
      <button
        type="button"
        class="btn btn-primary"
        @click="change">
        Save
      </button>
    </div>
  </b-modal>
</template>

<script>
import UserApiService from '@/api-services/user.service';
export default {
  name: 'EditName',
    props: ['firstName', 'lastName'],
  methods: {
      change() {
          const payload = {firstName: this.firstName, lastName: this.lastName};
          this.$emit('changed', payload);
          UserApiService.saveName(payload).then((resp)=>{
               if(resp.status == 200) {
                this.hideModal();
                this.$swal({
                    toast: true,
                    position: 'top',
                    showConfirmButton: false,
                    timer: 3000,
                    type: 'success',
                    title: 'Name changed'
                  });
              }else{
                this.$swal(resp.data.message, '', 'error');
              }
          },(error) => {
              const err = `${(error.response.data.errors['firstName'])?error.response.data.errors['firstName']:''} ${(error.response.data.errors['lastName'])?error.response.data.errors['lastName']:''}`;
              this.$swal(err.toString(), '', 'error');
          });
      },
    hideModal() {
      this.$refs.nameModal.hide();
    },
    showModal() {
      this.$refs.nameModal.show();
    }
  }
};
</script>

<style lang="scss">
  @import '@/assets/scss/modal-common.scss'
</style>

