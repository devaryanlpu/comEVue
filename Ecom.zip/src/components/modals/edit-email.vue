<template>
  <b-modal class="modal-box" ref="emailModal">
    <div slot="modal-header">
      <h5>Edit Email Address</h5>
      <span @click="hideModal">&times;</span>
    </div>
    <div class="d-block">
      Email Address
      <b-input
        v-model="email"
        placeholder="Enter your new email address"
      >

      </b-input>
    </div>
    <div slot="modal-footer">
      <button
        type="button"
        class="btn btn-primary"
        @click="change">
        Save
      </button>
    </div>
  </b-modal>
</template>

<script>
import UserApiService from '@/api-services/user.service';
export default {
  name: 'EditEmail',
    props: ['email'],
  methods: {
      change() {
          this.$emit('changed', this.email);
          UserApiService.saveEmail({email: this.email})
             .then((resp)=>{
               console.log(resp)
               if(resp.status == 200) {
                this.hideModal();
                this.$swal({
                    toast: true,
                    position: 'top',
                    showConfirmButton: false,
                    timer: 3000,
                    type: 'success',
                    title: 'Email changed'
                  });
              }else{
                this.$swal(resp.data.message, '', 'error');
              }
          },(error) => {
              const err = error.response.data.errors.email;
              this.$swal(err.toString(), '', 'error');
          });
      },
    hideModal() {
      this.$refs.emailModal.hide();
    },
    showModal() {
      this.$refs.emailModal.show();
    }
  }
};
</script>

<style lang="scss">
  @import '@/assets/scss/modal-common.scss'
</style>

