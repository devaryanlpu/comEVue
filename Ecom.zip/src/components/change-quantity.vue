<template>
  <div class="change-quantity">
    <button type="button" class="btn-qty btn btn-primary" @click="updateQty(qty - 1)">-</button>
    <input v-model="qty" type="number" class="form-control" min="0" disabled>
    <button type="button" class="btn-qty btn btn-primary" @click="updateQty(qty + 1)">+</button>
  </div>
</template>

<script>
import CartApiService from '@/api-services/cart.service';

export default {
  name: 'ChangeQuantity',
  props: {
    qty: {
      type: Number,
      default: 0
    },
    cartItem: {
      type: Object,
      default: null
    },
    limit: {
      type: Number,
      default: 1
    },
    special: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      quantity: this.qty
    };
  },
  methods: {
    updateQty(value) {
      
      // if(value > this.limit) {
      //   alert('Out of stock');
      //   return;
      // }
      if (value < 0) {
        return;
      }
      this.$emit('quantityUpdated', value);

      if (!this.cartItem) return;
      if (value === 0) {
        this.overlayActive = false;
        this.$store.state.addingToCart = true;
        CartApiService.removeItem(this.cartItem.store_product_id  || this.cartItem.id)
          .then(() => {
            this.quantity = 0;
            this.$store.dispatch("fetchCartItemsDetails");
            this.$store.state.addingToCart = false;
          });
      } else {
        this.$store.state.addingToCart = true;
        CartApiService.addItem(this.cartItem.store_product_id || this.cartItem.id, value)
          .then(() => {
            this.quantity = value;
            this.$store.dispatch("fetchCartItemsDetails");
            this.$store.state.addingToCart = false;
          })
          .catch(() => {
            alert('Out of stock!');
          });
      }
    }
  }
};
</script>

