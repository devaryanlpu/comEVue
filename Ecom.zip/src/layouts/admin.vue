<template>
  <div>
    <!-- Main EZ-AD Header -->
    <main-header></main-header>

    <!-- Visitor's site header -->
    <!--<site-header></site-header>-->
    <slot />

    <!-- Admin footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <h5>Payment</h5>
            <div id="payment-methods">
              <a href="https://www.mastercard.us/en-us.html" target="_blank">
                <img src="/icons/mastercard.png" alt="Master Card" class="img-fluid">
              </a>
              <a href="https://visa.com" target="_blank">
                <img src="/icons/visa.png" alt="Visa" class="img-fluid">
              </a>
              <a href="https://paypal.com" target="_blank">
                <img src="/icons/paypal.png" alt="PayPal" class="img-fluid">
              </a>
              <a href="https://www.americanexpress.com" target="_blank" class="mr-0">
                <img src="/icons/express.png" alt="American Express" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-md-6 mt-4 mt-md-0">
                 <social-connect :connect="business"/>
          </div>
        </div>
      </div>
      <hr>
      <div class="container">
        <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of
          them does not imply any affiliation with or endorsement by them.</p>
      </div>
    </footer>
  </div>
</template>

<script>
  import HomePageApiService from '@/api-services/homepage.service';

  export default {
    name: 'AdminLayout',
    data() {
      return {
        business: {
          facebook_link: '',
          twitter_link: '',
          instagram_link: '',
          youtube_link: '',
        },
        banner: {
          message: 'Limited Time Offer: Free Delivery to your Home',
          button_title: 'Shop Now',
          custom_uri: ''
        }
      };
    },
    async mounted() {
      let resp = await HomePageApiService.getBusinessDetails();
      this.business = resp.data.data;
      this.$store.commit('setBusinessDetails', this.business);
    }
  };
</script>

<style lang="scss" scoped>
  .banner {
    background-color: #4A90E2;
    font-weight: 500;
    display: flex;
    justify-content: center;
    align-items: center;
    .banner-container {
      display: flex;
      a {
        .btn {
          font-weight: 500;
        }
      }

      .edit {
        margin-left: 8px;

        a {
          margin: 0 3px;
          cursor: pointer;
        }
      }
    }
  }

  @media (max-width: 991px) {
    .banner {
      padding: 10px 0;
      font-size: 12px;
      flex-direction: row;

      a {
        margin-left: 10px;
      }
    }
  }

  @media (max-width: 576px) {
    .banner {
      flex-direction: column;
    }
    .banner-container {
      .btn-outline-white {
        font-size: 12px;
        line-height: 12px;
      }

      .edit {
        margin-top: 5px;

        img {
          width: 24px;
        }
      }
    }
  }
</style>
