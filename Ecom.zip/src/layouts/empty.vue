<template>
  <div id="app">
    <slot />
  </div>
</template>
