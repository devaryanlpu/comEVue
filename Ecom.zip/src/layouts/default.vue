<template>
  <div class="sticky-page">
    <header-black ref="mainHeader"/>
    <b-navbar toggleable="lg" type="dark" class="sticky-header" variant="white" ref="mainMobileHeader" style="margin-top: -2px">
      <b-container>
        <b-navbar-toggle target="navContent" />
        <div class="quick-links d-flex d-lg-none">
          <div class="search d-inline-block w-100 px-4">
            <vue-autosuggest
              ref="autocomplete"
              :suggestions="searchSuggestions"
              :inputProps="inputProps"
              :sectionConfigs="sectionConfigs"
              :renderSuggestion="renderSuggestion"
              :getSuggestionValue="getSuggestionValue"
            >
              <template slot="footer">
                <div class="search-suggestion-footer">
                  None of the results match?
                  <span class="search-link" @mouseup="toSearchPage">Click here</span>
                </div>
              </template>
            </vue-autosuggest>
          </div>
          <router-link to="/cart" class="btn btn-primary cart">
            <img src="/icons/cart.svg" alt="Cart">
            <span v-if="cart" class="badge badge-pill badge-dark ml-1">{{ cartAmount }}</span>
          </router-link>
        </div>
        <b-collapse id="navContent" is-nav>
          <a class="navbar-brand d-block d-md-none my-2" href="/">
            <img class="brand-logo-image mr-2" src="/icons/ObermeierSolidMaroon-01.svg" alt="Logo">
            <!--<h1 class="d-inline-block text-white">Obermeier Hardware</h1>-->
          </a>
          <b-navbar-nav class="mr-auto">
            <b-nav-item to="/">Home</b-nav-item>
            <b-nav-item-dropdown text="Departments" class="department-list">
               <li class="w-100 px-3">
                <input type="text" class="form-control" v-model="departmentDropdownSearch" placeholder="Search departments.."/>
              </li>
              <b-dropdown-item
                v-for="(dep,i) in filteredDepartmentList" :key="i"
                :to="{ name: 'search', query: { deptId: dep.id, deptName: dep.name }}">
                {{ dep.name | capitalize }}
              </b-dropdown-item>
            </b-nav-item-dropdown>            
            <!-- <b-nav-item-dropdown text="Information pages" class="info-pages">
              <b-dropdown-item :to="'/departments/car_hartt'">Carhartt</b-dropdown-item>
              <b-dropdown-item :to="'/departments/hand_tools'">Hand Tools</b-dropdown-item>
              <b-dropdown-item :to="'/departments/power_tools'">Power Tools</b-dropdown-item>
              <b-dropdown-item :to="'/departments/doors'">Doors</b-dropdown-item>
              <b-dropdown-item :to="'/departments/garden_tools'">Garden Tools</b-dropdown-item>
              <b-dropdown-item :to="'/departments/recreation'">Recreation</b-dropdown-item>
              <b-dropdown-item :to="'/departments/ponds'">Ponds</b-dropdown-item>
              <b-dropdown-item :to="'/departments/siding_and_trim'">Siding & Trim</b-dropdown-item>
              <b-dropdown-item :to="'/departments/roofing'">Roofing</b-dropdown-item>
              <b-dropdown-item :to="'/departments/lumber'">Lumber</b-dropdown-item>
              <b-dropdown-item :to="'/departments/paint'">Paint</b-dropdown-item>
              <b-dropdown-item :to="'/departments/outdoor_power_equipment'">Outdoor Power Equipment</b-dropdown-item>
              <b-dropdown-item :to="'/departments/rental'">Rental</b-dropdown-item>
              <b-dropdown-item :to="'/departments/nursery'">Nursery</b-dropdown-item>
            </b-nav-item-dropdown> -->
            <b-nav-item to="/brands">Brands</b-nav-item>
            <b-nav-item v-if="!activeUser" to="/login" class="d-md-none">Login</b-nav-item>
            <!-- <b-nav-item to="/virtual_tour">Virtual Tour</b-nav-item> -->
          </b-navbar-nav>

          <b-navbar-nav class="ml-auto">
            <li class="nav-item">
              <a href="tel:(530) 273-6171" class="nav-link phone">
                <div class="phone-text"></div>
                <span>(530) 273-6171</span>
              </a>
            </li>
            <li class="nav-item">
              <router-link to="/aboutus" class="nav-link alt-link">About Us</router-link>
            </li>
          </b-navbar-nav>
        </b-collapse>
      </b-container>
    </b-navbar>

    <slot/>

    <footer>
      <div class="container">
        <div class="row">
          <!-- <div class="col-md-6">
            <h5>Payment</h5>
            <div id="payment-methods">
              <a href="https://www.mastercard.us/en-us.html" target="_blank">
                <img src="/icons/mastercard.png" alt="Master Card" class="img-fluid">
              </a>
              <a href="https://visa.com" target="_blank">
                <img src="/icons/visa.png" alt="Visa" class="img-fluid">
              </a>
              <a href="https://paypal.com" target="_blank">
                <img src="/icons/paypal.png" alt="PayPal" class="img-fluid">
              </a>
              <a href="https://www.americanexpress.com" target="_blank" class="mr-0">
                <img src="/icons/express.png" alt="American Express" class="img-fluid">
              </a>
            </div>
            <div class="privacy-link">
              <router-link to="/terms">Terms and Policies</router-link>
            </div>
          </div> -->

          <div class="col-md-6 mt-4 mt-md-0">
            <social-connect :connect="business"/>
          </div>
        </div>
      </div>
      <hr>
      <div class="container">
        <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of
          them does not imply any affiliation with or endorsement by them.</p>
      </div>
    </footer>
  </div>
</template>

<script>
import { debounce } from "debounce";
import DepartmentApiService from '@/api-services/departments.service';
import HomePageApiService from '@/api-services/homepage.service';

export default {
  name: "DefaultLayout",
  data() {
    return {
      business: {
        facebook_link: '',
        twitter_link: '',
        instagram_link: '',
        pinterest_link: '',
        youtube_link: '',
        linkedin_link: '',
      },
      searchKey: null,
      addSticky: false,
       departmentDropdownSearch: '',
      inputProps: {
        id: "autosuggest__input",
        onInputChange: this.getSuggestions,
        placeholder: "Enter what you are looking for",
        class: "form-control",
        name: "searchKey"
      },
      sectionConfigs: {
        products: {
          limit: 10,
          label: "Products",
          onSelected: selected => {
            this.searchKey = selected.item.title;
            this.$router.push({
              name: "products-id",
              params: {
                id: selected.item.sku,
                title: selected.item.title.replace(/[ /]/g, "+")
              }
            });
          }
        },
        departments: {
          limit: 3,
          label: "Departments",
          onSelected: selected => {
            this.searchKey = selected.item.name;
            this.toSearchPage();
          }
        },
        default: {
          onSelected: () => {
            this.toSearchPage();
          }
        }
      }
    };
  },
  async mounted() {
    if(!this.$store.state.departmentResults) {
      let response = await DepartmentApiService.getDepartments();
      this.$store.commit('saveDepartments', response.data.data);
    }

    let resp = await HomePageApiService.getBusinessDetails();
    this.business = resp.data.data;
    this.$store.commit('setBusinessDetails', this.business);
  },
  computed: {
    departmentList() {
      if(this.$store.state.departmentResults) {
        return this.$store.state.departmentResults.parent_departments.map(e => {
          let name = e.name.indexOf('-') > 0 ? e.name.split('-')[1].slice(1) : e.name;
          return { id: e.dept_id, name: name };
        });
      } else {
        return [];
      }
    },
     filteredDepartmentList() {
      return this.departmentList.filter(department => {
        return department.name.toLowerCase().includes(this.departmentDropdownSearch.toLowerCase());
      });
    },
    cart() {
      return this.$store.state.cart;
    },
    cartAmount() {
      //return this.$store.getters.cartTotal;
      return this.$store.state.cartItemCount;
    },
    banner() {
      return this.$store.state.banner;
    },
    activeUser() {
      return this.$store.state.activeUser;
    },
    searchSuggestions() {
      if(this.$store.state.searchSuggestions) {
        let arr = this.$store.state.searchSuggestions;
        let temp = [];
        const products = arr.products && arr.products.items;
        const departments = arr.departments && arr.departments.items;
        products.length && temp.push({ name: 'products', data: products });
        departments.length && temp.push({ name: 'departments', data: departments });
        return temp;
      }
      else
        return [];
    },
    preferences() {
      return this.$store.state.preferences;
    }
  },
  created() {
    this.$store.dispatch("fetchCartItemsDetails");
    this.$store.dispatch("fetchBanner");
    window.addEventListener('scroll', this.handleScroll);
  },
  destroyed() {
    window.removeEventListener('scroll', this.handleScroll);
  },
  methods: {
    toSearchPage() {
      if (this.searchKey) {
        this.$store.dispatch("clearSearch");
        this.$store.dispatch("search", {
          search: this.searchKey,
        });
        if (this.$route.name === "search") {
          let query = Object.assign({}, this.$route.query, {
            keyword: this.searchKey,
            limit: 48
          });
          this.$router.push({ query: query });
        } else {
          this.$router.push({
            name: "search",
            query: {
              keyword: this.searchKey,
              limit: 48
            }
          });
        }
      }
    },

    getSuggestions(text) {
      if (text == "" || text == undefined) return;
      this.searchKey = text;
      this.$store.dispatch("searchSuggestion", this.searchKey);
    },

    renderSuggestion(suggestion) {
      const item = suggestion.item;
      if (suggestion.name == 'products') {
        return (
          <div>
            <img class={{ avatar: true }} src={ item.image_url } />
            { item.title }
          </div>
        );
      } else if (suggestion.name == 'departments') {
        if(item.parent) {
          return (
            <div style="font-size: 12px;">
              <span>{ item.name }</span>
              <span style="color: grey;"> in </span>
              <span style="color: grey; font-size: 11px;">{ item.parent.name }</span>
            </div>
          );
        } else
          return (
            <div style="font-size: 12px;">
              <span>{ item.name }</span>
            </div>
          );
      }
    },

    getSuggestionValue(suggestion) {
      let { name, item } = suggestion;
      return name == "products" ? item.title : item.name;
    },

    handleScroll() {
      if(window.pageYOffset == 0){
        this.addSticky = false;
      } else {
        this.addSticky = this.$refs.mainHeader.addSticky;
      }
    }
  },
  watch: {
    searchKey: debounce(function(newQuery) {
      this.getSuggestions(newQuery);
    }, 250)
  },
  filters: {
    capitalize: function (value) {
      if (!value) return '';
      value = value.toString().toLowerCase();
      return value.charAt(0).toUpperCase() + value.slice(1);
    }
  }
};
</script>

<style>
  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 10px;
    width: 100%;
  }

  nav.navbar .quick-links li {
    display: inline-table;
    height: auto;
    line-height: 16px;
  }

  .navbar-nav .info-pages .dropdown-menu {
    flex-wrap: wrap;
    min-width: 400px;
  }

  .navbar-nav .department-list .dropdown-menu {
    flex-wrap: wrap;
    min-width: 575px;
  }

  .navbar-nav .b-nav-dropdown .dropdown-menu li {
    float: left;
    width: 50%;
  }

  .autosuggest__results .autosuggest__results_title {
    width: 100%;
  }

  .phone-text > .fa-icon {
    fill: #A02230;
  }
  @media screen and (max-width: 768px) {
    .navbar-nav .b-nav-dropdown .dropdown-menu {
      position: absolute;
      min-width: 320px !important;
    }
    .navbar-nav .b-nav-dropdown .dropdown-menu li {
      float: none;
      width: 100%;
    }
  }
</style>
