import Axios from 'axios';
import store from '@/store';

const ENDPOINTS = {
  ABOUTUS: {
    SAVE: 'about-us/save',
    GET: 'about-us'
  },
  POSINFO: {
    SAVE: 'pos-settings/save',
    GET: 'pos-settings/stores'
  },
  SOCIAL: {
    UPDATE: 'social/update'
  },
  ORDERS: {
    OUTSTANDING: 'admin/orders/outstanding',
    COMPLETED: 'admin/orders/completed',
    ORDER: 'admin/orders/'
  }
};

export default {
  getAbout() {
    return Axios.get(ENDPOINTS.ABOUTUS.GET, {
      headers: { 
        'Business-Slug': store.state.business_slug
      }
    });
  },
  saveAbout(data) {
    return Axios.post(ENDPOINTS.ABOUTUS.SAVE, data, {
      headers: { 
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },

  getPosInfo() {
    return Axios.get(ENDPOINTS.POSINFO.GET, {
      headers: { 
        'Business-Slug': store.state.business_slug
      }
    });
  },
  savePosInfo(data) {
    return Axios.post(ENDPOINTS.POSINFO.SAVE, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },

  updateSocialLink(data) {
    return Axios.post(ENDPOINTS.SOCIAL.UPDATE, data, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        'Business-Slug': store.state.business_slug
      }
    });
  },

  getOutstandingOrders(data) {
    let params = data ? `?types=${data}` : '';
    return Axios.get(ENDPOINTS.ORDERS.OUTSTANDING + params, {
      headers: { 
        'Business-Slug': store.state.business_slug,
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      }
    });
  },
  getCompletedOrders(data = {}) {
    // {types: 'pickup,delivery,special', dateStart: '2019-09-01', dateEnd: '2019-10-31', page: 1, perPage: 10}

    return Axios.get(ENDPOINTS.ORDERS.COMPLETED, {
      headers: { 
        'Business-Slug': store.state.business_slug,
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      },
      data: data
    });
  },
  getOrder(id = '', itemIds) {
    let itemIds_param = itemIds ? `?itemIds=${itemIds}` : '';
    return Axios.get(ENDPOINTS.ORDERS.ORDER + id + itemIds_param, {
      headers: { 
        'Business-Slug': store.state.business_slug,
        'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
      },
    });
  }
};
