import Axios from 'axios';

const ENDPOINTS = {
  ADD: 'add-subscriber'
};

export default {
  subscribe(email) {
    let data = {
      email
    };

    return Axios.post(ENDPOINTS.ADD, data);
  }
};
