import Axios from 'axios';

const ENDPOINTS = {
  FETCH: 'home-banner'
};

export default {
  getBanner() {
    return Axios.get(`${ENDPOINTS.FETCH}`);
  }
};
