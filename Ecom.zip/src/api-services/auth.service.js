import Axios from 'axios';

const ENDPOINTS = {
  LOGIN: 'login',
  LOGIN_PHONE: 'verify-otp',
  SEND_OTP: 'send-otp',
  LOGOUT: 'logout',
  FORGOT: 'forget-password',
  RESET: 'reset-password',
};

export default {
  login(email, password) {
    return Axios.post(ENDPOINTS.LOGIN, { email, password });
  },
  loginByPhone(telephone, otp) {
    return Axios.post(ENDPOINTS.LOGIN_PHONE, { telephone, otp });
  },
  sendOTP(telephone) {
    return Axios.post(ENDPOINTS.SEND_OTP, { telephone });
  },
  logout() {
    let token = localStorage.getItem('token') || sessionStorage.getItem('token');
    return Axios.post(`${ENDPOINTS.LOGOUT}?access_token=${token}`);
  },
  forgotPassword(email) {
    return Axios.post(`${ENDPOINTS.FORGOT}?email=${email}`);
  },
  resetPassword(code, password) {
      return Axios({
          method: 'post',
          url: ENDPOINTS.RESET,
          data: {
            code: code,
            password: password,
            password_confirmation: password
          }
      });
  }
};
