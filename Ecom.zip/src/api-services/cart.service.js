import Axios from 'axios';
import store from '@/store';

const ENDPOINTS = {
  ADD_TO_CART: 'add-to-cart',
  CART_DETAILS: 'cart-parcels',
  COUNT: 'count-cart-items',
  REMOVE_ITEM: 'remove-cart-item',
  EMPTY: 'empty-cart'
};

export default {
  addItem(id, qty) {
    let data = {
      store_product_id: id,
      quantity: qty
    };

    let activeUser = store.state.activeUser;
    if (!activeUser) {
      data.device_id = store.state.device_id;
    } else {
      data.customer_slug = activeUser.data.customer.slug;
    }

    return Axios.post(ENDPOINTS.ADD_TO_CART, data);
  },
  cartDetails() {
    let queryString = '';
    let activeUser = store.state.activeUser;
    if (!activeUser) {
      queryString = 'device_id=' + store.state.device_id;
    } else {
      queryString = 'customer_slug=' + activeUser.data.customer.slug;
    }

    return Axios.get(`${ENDPOINTS.CART_DETAILS}?${queryString}`);
  },
  itemsCount() {
    let queryString = '';
    let activeUser = store.state.activeUser;

    if (!activeUser) {
      queryString = 'device_id=' + store.state.device_id;
    } else {
      queryString = 'customer_slug=' + activeUser.data.customer.slug;
    }

    return Axios.get(`${ENDPOINTS.COUNT}?${queryString}`);
  },
  removeItem(id) {
    let queryString = '';
    let activeUser = store.state.activeUser;

    if (!activeUser) {
      queryString = 'device_id=' + store.state.device_id;
    } else {
      queryString = 'customer_slug=' + activeUser.data.customer.slug;
    }

    return Axios.delete(`${ENDPOINTS.REMOVE_ITEM}?store_product_id=${id}&${queryString}`);
  }
};
