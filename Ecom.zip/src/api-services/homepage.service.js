import Axios from 'axios';

const ENDPOINTS = {
  FETCH: 'homepage-widgets',
  BUSINESS_DETAILS: 'business-details'
};

export default {
  getSections() {
    return Axios.get(`${ENDPOINTS.FETCH}`);
  },
  getPreferences() {
    return Promise.resolve({
      brands: true,
      departments: true,
      coupons: true,
      payment: true,
      stock: true
    });
  },
  getBusinessDetails() {
    return Axios.get(`${ENDPOINTS.BUSINESS_DETAILS}`);
  },
};
