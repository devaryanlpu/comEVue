import Axios from 'axios';

const ENDPOINTS = {
  SEARCHSUGGESTIONS: 'get-suggestions',
  SEARCHRESULTS: 'products',
  SEARCHSTORE: 'nearby-stores',
};

export default {
  searchSuggestions(keyword) {
    return Axios.get(`${ENDPOINTS.SEARCHSUGGESTIONS}?search=${keyword}`);
  },
  searchResults(params) {
    return Axios.get(`${ENDPOINTS.SEARCHRESULTS}`, { params });
  },
  nearbyStore(params) {
    return Axios.get(`${ENDPOINTS.SEARCHSTORE}`, { params });
  }
};
