<template>
  <div class="container">
    {{order}}
    <h5 class="page-breadcrumbs">Prepare Order</h5>
    <div class="prepare-order">
      <div class="customer-detail">
        <div class="order-header">
          <h4>Prepare Order #{{ order.id }}</h4>
          <button class="btn btn-outline-secondary" @click="showMsgBoxTwo">Cancel</button>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="order-details-info">
              <div class="card-customer">
                <span class="person-detail">
                  <h5>Customer Details</h5>
                  <h3>{{ order.first_name }} {{ order.last_name }}</h3>
                </span>
                <P>1234 Boss Street
                  Santa Clarita, CA 91325
                </P>
                <div class="contact-detail">
                  <div>{{ order.telephone }}</div>
                  <div>{{ order.email }}</div>
                </div>
              </div>
              <div class="details-info">
                <a :href="`tel:${order.telephone}`"><img src="/icons/phone.png"/>Call</a>
                <a :href="`mailto:${order.email}`"><img src="/icons/mail.png"/>Email</a>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="order-type-details">
            <span class="person-detail mb-1">
              <h6>Order Type</h6>
              <h5 class="blue" v-if="orderType === 'special'">Shipping</h5>
              <h5 class="green" v-if="orderType === 'pickup'">Pickup</h5>
              <h5 class="orange" v-if="orderType === 'delivery'">Delivery</h5>
            </span>
              <span class="person-detail mb-2">
              <h6 v-if="orderType === 'shipping'">Shipping Time</h6>
              <h6 v-if="orderType === 'pickup'">Pickup Time</h6>
              <h6 v-if="orderType === 'delivery'">Delivery Time</h6>
              <span>04/25/2019 &nbsp;<p>3:00-4:00 PM</p></span>
            </span>
              <span class="person-detail">
              <h6>Order Placed</h6>
             <span>04/25/2019 &nbsp;<p>3:00-4:00 PM</p></span>
            </span>
            </div>
          </div>
        </div>
      </div>
      <div class="prepare-items-box">
        <b-tabs v-model="activeTab" :no-key-nav="true">
          <b-tab :disabled="disableFirstTab" :title-link-class="{'disable-tab': activeTab > 0}">
            <template slot="title">
              <span v-if="activeTab > 0"><img src="/icons/d-check.png"/></span>
              <span v-else>1</span>
              Prepare Items
            </template>
          </b-tab>
          <b-tab :disabled="disableSecondTab" :title-link-class="{'disable-tab': activeTab > 1}">
            <template slot="title">
              <span v-if="activeTab > 1"><img src="/icons/d-check.png"/></span>
              <span v-else>2</span>
              Package
            </template>
          </b-tab>
          <b-tab :disabled="disableThirdTab">
            <template slot="title">
              <span>3</span>
              <template v-if="orderType === 'shipping'">Mark as Prepared & Ship</template>
              <template v-if="orderType === 'pickup'">Mark as Prepared & Transfer to Pickup Area</template>
              <template v-if="orderType === 'delivery'">Mark as Prepared & Deliver</template>
            </template>
          </b-tab>
          <template v-if="activeTab === 0">
            <div class="items-pick">
              <h4>Pick the items to prepare them for shipping.</h4>
              <h6>Check off all of the items on the checklist before proceeding.</h6>
              <div class="item-table p-3 w-100">
                <div class="order-table">
                  <div class="table-header">
                    <h5>GRASS VALLEY LOCATION</h5>
                  </div>
                  <b-table striped hover :items="items" :fields="fields" thead-class="d-none">
                    <template slot="checklist" slot-scope="data">
                      <div class="pt-3 custom-control custom-checkbox text-center">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input"
                               :id="'prepare-item-' + data.index" checked>
                        <label class="custom-control-label" :for="'prepare-item-' + data.index"></label>
                      </div>
                    </template>
                    <template slot="photo" slot-scope="data">
                      <img :src="data.item.photo"/>
                    </template>
                    <template slot="product" slot-scope="data">
                      {{data.item.product}}
                    </template>
                    <template slot="location" slot-scope="data">
                      {{data.item.location}}
                    </template>
                    <template slot="cost" slot-scope="data">
                      {{data.item.cost}}
                    </template>
                  </b-table>
                  <div class="table-header">
                    <h5>SPECIAL ORDER FROM (vendor_id)</h5>
                  </div>
                  <b-table striped hover :items="specialItems" :fields="fields" thead-class="d-none">
                    <template slot="checklist" slot-scope="data">
                      <div class="pt-3 custom-control custom-checkbox text-center">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input"
                               :id="'prepare-item-' + data.index" checked>
                        <label class="custom-control-label" :for="'prepare-item-' + data.index"></label>
                      </div>
                    </template>
                    <template slot="photo" slot-scope="data">
                      <img :src="data.item.photo"/>
                    </template>
                    <template slot="product" slot-scope="data">
                      {{data.item.product}}
                    </template>
                    <template slot="location" slot-scope="data">
                      {{data.item.location}}
                    </template>
                    <template slot="cost" slot-scope="data">
                      {{data.item.cost}}
                    </template>
                  </b-table>
                  <div class="total-custom">
                    <div class="pages">
                      <span><p>Subtotal (3 items)</p><h5>$200,95</h5></span>
                      <span><p>Taxes</p><h5>$35</h5></span>
                      <span><p>Total</p><h5>$235,95</h5></span>
                    </div>
                  </div>
                </div>
                <div class="btn-badges flex-end">
                  <button class="btn btn-primary" @click="setActiveTab(1)">
                    Next <img src="/icons/arrow-right.png" class="ml-2"/></button>
                </div>
              </div>
            </div>
          </template>
          <template v-if="activeTab === 1">
            <div class="wrapper-content">
              <ul>
                <li>
                  <a>
                    <div class="round-head">1</div>
                    <span>
                      <h3>Packing</h3>
                      <p>Protect the items with protective packing material, for example wrapping the products with bubble
                        wrap or filling the box with peanuts. When completed, place the items into your box. </p>
                    </span>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input"
                               id="package-packing"/>
                        <label class="custom-control-label" for="package-packing"></label>
                      </div>
                    </div>
                  </a>
                </li>
                <li>
                  <a>
                    <div class="round-head">2</div>
                    <span>
                      <h3>Order Receipt</h3>
                      <p>Print and insert this document inside of the box as a receipt confirmation. </p>
                    </span>
                    <button class="btn btn-outline-primary"><img src="/icons/printer.png"/>Print</button>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input"
                               id="package-order-receipt"/>
                        <label class="custom-control-label" for="package-order-receipt"></label>
                      </div>
                    </div>
                  </a>
                </li>
                <li v-if="orderType !== 'pickup'">
                  <a>
                    <div class="round-head">3</div>
                    <span>
                      <h3>Shipping Label</h3>
                      <p>Print and paste this document on the outside of the box. </p>
                    </span>
                    <button class="btn btn-outline-primary"><img src="/icons/printer.png"/>Print</button>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input" value="true"
                               id="shipping-label-checkbox">
                        <label class="custom-control-label" for="shipping-label-checkbox"></label>
                      </div>
                    </div>
                  </a>
                </li>
                <li>
                  <a>
                    <div class="round-head">{{orderType === 'pickup' ? 3 : 4}}</div>
                    <span>
                      <h3>Seal Your Package</h3>
                      <p>Close the small ends to form the bottom of your box, following with the larger ends. Seal the box with tape along all 3 seams on both ends of the box. </p>
                    </span>
                    <div class="check">
                      <div class="m-1 custom-control custom-checkbox">
                        <input type="checkbox" autocomplete="off"
                               class="custom-control-input" value="true"
                               id="package-seal-your-package">
                        <label class="custom-control-label" for="package-seal-your-package"></label>
                      </div>
                    </div>
                  </a>
                </li>
              </ul>
              <span class="error-text text-center d-none">
                <img src="/icons/c-warning.png"/>
                Make sure all checklist boxes are checked and press the “Next” button.
              </span>
            </div>
            <div class="btn-badges">
              <button class="btn btn-outline-secondary" @click="setActiveTab(0)">Previous</button>
              <button class="btn btn-primary" @click="setActiveTab(2)">
                Next <img src="/icons/arrow-right.png" class="ml-2"/></button>
            </div>
          </template>
          <template v-if="activeTab === 2">
            <div class="success-box">
              <div class="img-suc">
                <img src="/icons/success.png"/>
                <h5>Success!</h5>
                <p>
                  You’ve finished preparing your order.
                  You may now mark your order as prepared and transfer it to the shipping area.
                  Job well done!
                </p>
              </div>
              <button class="btn btn-primary" @click="goToOrders()">Mark as Prepared</button>
            </div>
            <button class="btn-prev btn btn-outline-secondary m-3" @click="setActiveTab(1)">
              Previous
            </button>
          </template>
        </b-tabs>
      </div>
    </div>
  </div>
</template>
<script>
  import AdminService from '@/api-services/admin.service';

  export default {
    name: 'AdminPrepareOrder',
    data() {
      return {
        activeTab: 0,
        order: {},
        orderId: null,
        disableFirstTab: false,
        disableSecondTab: false,
        disableThirdTab: false,
        fields: ['checklist', 'photo', 'product', 'location', 'cost'],
        items: [
          {
            checklist: 1,
            photo: '/icons/small-img.png',
            product: 'Garden hose 734732',
            location: 'Aisle 1',
            cost: '$320,24'
          },
          {
            checklist: 2,
            photo: '/icons/small-img.png',
            product: 'Garden hose 734732',
            location: 'Aisle 1',
            cost: '$320,24'
          },
          {
            checklist: 3,
            photo: '/icons/small-img.png',
            product: 'Garden hose 734732',
            location: 'Aisle 1',
            cost: '$320,24'
          },
          {
            checklist: 4,
            photo: '/icons/small-img.png',
            product: 'Garden hose 734732',
            location: 'Aisle 1',
            cost: '$320,24'
          },
        ],
        specialItems: [
          {
            checklist: 6,
            photo: '/icons/small-img.png',
            product: 'Garden hose 734732',
            location: 'Aisle 1',
            cost: '$320,24'
          }
        ]
      };
    },
    beforeMount() {
      if (!this.$route.query || !this.$route.query.id) {
        this.goToOrders();
      } else {
        this.orderId = this.$route.query.id;
      }
    },
    async mounted() {
      let resp = await AdminService.getOrder(this.orderId);
      this.order = resp.data.order;
      setTimeout(() => {
        this.setActiveTab(0);
      }, 100);
    },
    methods: {
      setActiveTab(index) {
        this.activeTab = index;
        switch (index) {
          case 0: {
            this.disableFirstTab = false;
            this.disableSecondTab = true;
            this.disableThirdTab = true;
            break;
          }
          case 1: {
            this.disableFirstTab = true;
            this.disableSecondTab = false;
            this.disableThirdTab = true;
            break;
          }
          case 2: {
            this.disableFirstTab = true;
            this.disableSecondTab = true;
            this.disableThirdTab = false;
            break;
          }
        }
      },
      showMsgBoxTwo() {
        this.$bvModal.msgBoxConfirm('Are you sure you want to cancel preparing this order?', {
          size: 'sm',
          buttonSize: 'sm',
          okVariant: 'success',
          cancelClass:'cancel-class',
          cancelVariant: 'default',
          okTitle: 'YES',
          cancelTitle: 'NO',
          footerClass: 'p-2 confirmation-footer',
          hideHeaderClose: false,
          centered: true
        })
        .then(value => {
          if (value) {
            this.goToOrders();
          }
        });
      },
      goToOrders() {
        this.$router.push({name: 'admin-orders'});
      }
    }
  };
</script>
<style lang="scss">
  .page-breadcrumbs {
    margin-bottom: 0;
    padding: 20px 0;
    font-weight: 600;
  }
  .confirmation-footer {
    justify-content: space-between;
    .btn-default {
      border: 1px solid #E6E6E6;
    }
  }
  .prepare-order {
    background: #FFFFFF;
    border: 1px solid #EAEAEB;
    border-radius: 5px;
    .customer-detail {
      padding: 24px;
      .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
      }
      h4 {
        font-weight: bold;
        font-size: 24px;
        line-height: 28px;
        color: #181C20;
        margin-bottom: 15px;
      }
      .order-details-info {
        background: #FFFFFF;
        border: 1px solid #E6E6E6;
        box-sizing: border-box;
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
        border-radius: 8px;
        padding: 15px;
        display: flex;
        justify-content: space-between;
        .card-customer {
          .person-detail {
            margin-bottom: 10px;
            h5 {
              font-weight: 500;
              font-size: 14px;
              line-height: 16px;
              color: #ACACAC;
              margin-bottom: 0;
            }
            h3 {
              font-size: 18px;
              line-height: 21px;
              color: #1A212C;
              margin-bottom: 10px;
            }
          }
          p {
            font-size: 16px;
            line-height: 19px;
            color: #1A212C;
            max-width: 200px;
            margin-bottom: 10px;
          }
          .contact-detail {
            font-size: 14px;
            line-height: 16px;
            color: #1A212C;
            text-decoration: none;
          }
        }
        .details-info {
          display: flex;
          flex-direction: column;
          a {
            font-size: 14px;
            line-height: 16px;
            border-radius: 5px;
            margin-bottom: 5px;
            padding: 6px;
            color: #181C20;
            border: 1px solid #E6E6E6;
            box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
            &:hover {
              text-decoration: none;
            }
            img {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .order-type-details {
      background: #FFFFFF;
      border: 1px solid #E6E6E6;
      box-sizing: border-box;
      box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
      border-radius: 8px;
      padding: 15px;
      .person-detail {
        display: flex;
        flex-direction: column;
        .blue {
          color: #0F84E4;
        }
        .green {
          color: #A02230;
        }
        .orange {
          color: #FD941D;
        }
        h6 {
          font-weight: 500;
          font-size: 14px;
          line-height: 18px;
          color: #ACACAC;
          margin-bottom: 0;
        }
        h5 {
          font-size: 18px;
          line-height: 21px;
          color: #0F84E4;
          margin-bottom: 0;
        }
        span {
          font-size: 16px;
          line-height: 19px;
          color: #1A212C;
          display: flex;
          p {
            margin-bottom: 0;
          }
        }
      }
    }
    .prepare-items-box {
      display: flex;
      .tabs {
        width: 100%;
        display: flex;
        flex-direction: column;
        div {
          .nav-tabs {
            display: flex;
            width: 100%;
            .nav-item {
              flex: 1 !important;
              .disable-tab {
                text-decoration: line-through;
              }
              .nav-link {
                border: none;
                text-align: center;
                color: #A5ADB8;
                span {
                  border-radius: 50%;
                  width: 15px;
                  height: 15px;
                  background: #A5ADB8;
                  color: #fff;
                  padding: 5px 10px;
                  margin-right: 8px;
                  img {
                    width: 10px;
                  }
                }
                &.active {
                  border-bottom: 2px solid #A02230;
                  color: #A02230;
                  span {
                    border-radius: 50%;
                    width: 15px;
                    height: 15px;
                    background: #A02230;
                    color: #fff;
                    padding: 5px 10px;
                    margin-right: 8px;
                  }
                }
              }
            }
          }
        }
      }
      .items-pick {
        display: flex;
        flex-direction: column;
        align-items: center;
        h4 {
          font-weight: bold;
          font-size: 23px;
          line-height: 27px;
          text-align: center;
          color: #181C20;
          margin-bottom: 0;
          margin-top: 25px;
        }
        h6 {
          font-size: 16px;
          line-height: 19px;
          text-align: center;
          color: #828282;
          font-weight: 300;
          margin-bottom: 0px;
        }
        .order-table {
          background: #FFFFFF;
          border: 1px solid #EAEAEB;
          border-radius: 5px;
          margin-top: 30px;
          .total-custom {
            padding: 0 24px 15px;
            .pages {
              display: flex;
              justify-content: flex-end;
              align-items: center;
              span {
                margin-left: 24px;
                p {
                  font-size: 14px;
                  line-height: 16px;
                  margin: 0;
                  color: #ACACAC;
                }
                h5 {
                  font-size: 17px;
                  line-height: 24px;
                  margin: 0;
                  color: #181C20;
                }
              }
            }
          }
          .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            h5 {
              font-size: 19px;
              line-height: 22px;
              color: #181C20;
              margin-bottom: 0;
            }
            .purchase-type {
              display: flex;
              align-items: center;
              h6 {
                margin-bottom: 0;
                margin-right: 5px;
                font-size: 14px;
                line-height: 16px;
                color: #181C20;
              }
              input[type="text"] {
                background: #FFFFFF;
                border: 1px solid #E6E6E6;
                box-sizing: border-box;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                border-radius: 5px;
                padding-left: 5px;
              }
            }
            .table-date-range {
              display: flex;
              align-items: center;
              h6 {
                margin-bottom: 0;
                margin-right: 5px;
                font-size: 14px;
                line-height: 16px;
                color: #181C20;
              }
              input[type="date"] {
                background: #FFFFFF;
                border: 1px solid #E6E6E6;
                box-sizing: border-box;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                border-radius: 5px;
                padding-left: 5px;
              }
              span {
                margin: 0 5px;
              }
            }
          }
          table {
            display: flex;
            flex-direction: column;
            thead {
              tr {
                display: flex;
                width: 100%;
                th {
                  flex: 1;
                  &:nth-of-type(3) {
                    flex: 2;
                  }
                  &:nth-of-type(5) {
                    flex: 2;
                  }
                }
              }
            }
            tbody {
              tr {
                display: flex;
                width: 100%;
                align-items: center;
                td {
                  flex: 1;
                  border: none;
                  &:nth-of-type(3) {
                    flex: 2;
                  }
                  &:nth-of-type(5) {
                    flex: 2;
                  }
                }
              }
            }
          }
          .pagination-custom {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
            .pages {
              display: flex;
              flex: 0.5;
              align-items: center;
              h6 {
                margin-bottom: 0;
                margin-right: 5px;
                font-size: 14px;
                line-height: 16px;
                color: #181C20;
              }
              input[type="text"] {
                background: #FFFFFF;
                border: 1px solid #E6E6E6;
                box-sizing: border-box;
                box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
                border-radius: 5px;
                padding-left: 5px;
              }
              span {
                margin: 0 5px;
              }
            }
            .pagination {
              margin: 0;
              flex: 1;
              display: flex;
              justify-content: flex-start !important;
            }
          }
        }
        .flex-end {
          justify-content: flex-end !important;
        }
        .btn-badges {
          display: flex;
          justify-content: space-between;
          padding: 15px 0;
        }
      }
    }
    .wrapper-content {
      ul {
        padding-left: 0;
        li {
          list-style: none;
          margin: 20px 0;
          padding: 0 20px;
          a {
            background: #F6F7F8;
            mix-blend-mode: normal;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px 15px 0;
            position: relative;
            min-height: 105px;
            .round-head {
              background: #181C20;
              border-radius: 50%;
              width: 35px;
              color: #fff;
              height: 35px;
              padding: 6px 14px;
              margin-left: 20px;
            }
            button {
              color: #000;
              border: 1px solid #E6E6E6;
              box-sizing: border-box;
              box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
              border-radius: 5px;
              background: #fff;
            }
            span {
              display: flex;
              flex-direction: column;
              padding: 0 20px;
              flex: 1;
              h3 {
                font-size: 23px;
                line-height: 27px;
                margin-bottom: 0;
                color: #181C20;
              }
              p {
                font-size: 16px;
                line-height: 19px;
                margin-bottom: 0;
                color: #828282;
              }
            }
            button {
              flex: 1;
              max-width: 120px;
              white-space: nowrap;
              padding: 2px 0 !important;
              margin: 0 30px;
              img {
                margin-right: 8px;
              }
            }
            .check {
              position: absolute;
              top: 15px;
              right: -5px;
            }
          }
        }
      }
      .error-text {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 15px auto;
        width: 100%;
        font-size: 14px;
        line-height: 16px;
        color: #4D4D4D;
        img {
          margin-right: 5px;
        }
      }
    }
    .btn-badges {
      display: flex;
      justify-content: space-between;
      padding: 15px;
    }
    .success-box {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      max-width: 330px;
      margin: 0 auto;
      padding: 50px 0 100px;
      .img-suc {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        align-items: center;
        h5 {
          font-size: 23px;
          line-height: 27px;
          text-align: center;
          color: #181C20;
          margin-top: 20px;
          margin-bottom: 15px;
          font-weight: 600;
        }
        p {
          font-size: 16px;
          line-height: 22px;
          text-align: center;
          color: #181C20;
          margin-bottom: 24px;
        }
      }
      .btn-primary {
        font-size: 18px;
        line-height: 16px;
        text-align: center;
        color: #FFFFFF;
      }
    }
    .btn-prev {
      display: flex;
      border: 1px solid #E6E6E6;
      box-sizing: border-box;
      box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.05);
      border-radius: 5px;
      font-size: 16px;
      color: #181C20;
      line-height: 19px;
    }
  }
</style>
