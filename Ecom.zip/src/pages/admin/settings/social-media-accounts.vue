<template>
  <div>
    <div class="px-5 d-flex pt-4 pb-3 mb-3 border-bottom justify-content-between align-items-center heading">
      <h1 class="h4 mb-0">Social Media Accounts</h1>
    </div>
    <div class="px-5 pb-5 mt-4">
      <p>
        Intergrate your social media with EZ-Commerce. Log in to your accounts to start connecting!
        <br>
        <span class="text-muted small">Log out of a social media account to hide it from the website.</span>
      </p>
      <form id="socialInputs">
        <div class="d-flex align-items-center align-items-sm-end mb-5">
          <div class="social-img mr-3">
            <img src="/images/social-facebook.png" width="80" alt="">
          </div>
          <div class="form-group mb-0" :class="{ 'form-group--error': !$v.facebook.validateUrl, 'valid': facebook != '' && $v.facebook.validateUrl }">
            <label class="small" for="facebook">Facebook</label>
            <input v-model.trim="$v.facebook.$model" type="text" id="facebook" name="facebook" class="form-control" @blur="saveData">
            <div class="invalid-feedback" style="display:block !important;" v-if="!$v.facebook.validateUrl">Please, insert a valid facebook url</div>
          </div>
        </div>
        <div class="d-flex align-items-center align-items-sm-end mb-5">
          <div class="social-img mr-3">
            <img src="/images/social-instagram.png" width="80" alt="">
          </div>
          <div class="form-group mb-0" :class="{ 'form-group--error': !$v.instagram.validateUrl, 'valid': instagram != '' && $v.instagram.validateUrl }">
            <label class="small" for="instagram">Instagram</label>
            <input type="text" v-model.trim="$v.instagram.$model" id="instagram" name="instagram" class="form-control" @blur="saveData">
            <div class="invalid-feedback" style="display:block !important;" v-if="!$v.instagram.validateUrl">Please, insert a valid instagram url</div>
          </div>
        </div>
        <div class="d-flex align-items-center align-items-sm-end mb-5">
          <div class="social-img mr-3">
            <img src="/images/social-twitter.png" width="86" alt="">
          </div>
          <div class="form-group mb-0" :class="{ 'form-group--error': !$v.twitter.validateUrl, 'valid': twitter != '' && $v.twitter.validateUrl }">
            <label class="small" for="twitter">Twitter</label>
            <input type="text" v-model.trim="$v.twitter.$model" id="twitter" name="twitter" class="form-control" @blur="saveData">
            <div class="invalid-feedback" style="display:block !important;" v-if="!$v.twitter.validateUrl">Please, insert a valid twitter url</div>
          </div>
        </div>
        <div class="d-flex align-items-center align-items-sm-end mb-5">
          <div class="social-img mr-3">
            <img src="/images/social-youtube.png" width="75" alt="">
          </div>
          <div class="form-group mb-0" :class="{ 'form-group--error': !$v.youtube.validateUrl, 'valid': youtube != '' && $v.youtube.validateUrl }">
            <label class="small" for="youtube">YouTube</label>
            <input type="text" v-model.trim="$v.youtube.$model" id="youtube" name="youtube" class="form-control" @blur="saveData">
            <div class="invalid-feedback" style="display:block !important;" v-if="!$v.youtube.validateUrl">Please, insert a valid youtube url</div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
  
  import HomepageService from '@/api-services/homepage.service';
  import AdminService from '@/api-services/admin.service';

  const validateUrl = param => {
    return value => {
      if (value == '')
        return true;
      var pattern = new RegExp('^(https?:\\/\\/)?'+
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+
        '((\\d{1,3}\\.){3}\\d{1,3}))'+
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+
        '(\\?[;&a-z\\d%_.~+=-]*)?'+
        '(\\#[-a-z\\d_]*)?$','i');
      if(pattern.test(value)) {
        return value.includes(`${param}.com`);
      }
      return false;
    };
  };
  export default {
    name: 'SocialMediaAccounts',
    data() {
      return {
        facebook: '',
        twitter: '',
        instagram: '',
        youtube: ''
      };
    },
    validations: {
      facebook: {
        validateUrl: validateUrl('facebook')
      },
      instagram: {
        validateUrl: validateUrl('instagram')
      },
      youtube: {
        validateUrl: validateUrl('youtube')
      },
      twitter: {
        validateUrl: validateUrl('twitter')
      },
    },
    async mounted() {
      let resp = await HomepageService.getBusinessDetails();
      this.facebook = resp.data.data.facebook_link || '';
      this.twitter = resp.data.data.twitter_link || '';
      this.instagram = resp.data.data.instagram_link || '';
      this.youtube = resp.data.data.youtube_link || '';
    },
    methods: {
      saveData(evt) {
        if(this.$v[evt.target.id].validateUrl) {
          if(evt.target.value != '') {
            AdminService.updateSocialLink({type: evt.target.id, url: evt.target.value});
          }
        }
      },
      checkDefaultText(evt) {
        let defaultText = evt.target.getAttribute('data-default');
        let val = evt.target.value;
        if(val.length <= defaultText.length) {
          evt.target.value = defaultText;
        }
      }
    }
  };
</script>

<style lang="scss" scoped>
  $primary: #A02230;
  .heading {
    height: 80px;
    .h4 {
      color: $primary;
    }
  }
  #socialInputs {
    input[type=text] {
      width: 100%;
    }
    .social-img {
      width: 100px;
      display: flex;
      justify-content: center;
      + .form-group {
        width: 290px;
      }
    }
  }
  .valid input {
    border-color: #A02230;
  }
  .form-group--error input {
    border-color: red;
  }

  @media (max-width: 500px) {
    #socialInputs {
      .social-img {
        width: 40px;
        display: none;
        img {
          width: 100%;
        }
      }
      .social-img + .form-group {
        flex: 1;
      }
    }
  }
</style>
