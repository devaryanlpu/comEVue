<template>
  <div>
    <div class="px-5 d-flex pt-4 pb-3 mb-3 border-bottom justify-content-between align-items-center heading">
      <h1 class="h4 mb-0">POS Data Syncer</h1>
    </div>
    <div v-for="(store, index) in stores" :key="index" class="px-5 pb-5 mt-4 store-box">
      <h2 class="h3 mb-4">{{ store.name }} POS Info</h2>
      <p>
        <span v-for="(data, key, i) in store.data" :key="i" class="mr-3">
          <b>{{ key }}:</b> {{ data }}
        </span>
      </p>
      <div class="info-lists row my-4">
        <div class="col-md-4">
          <h5>Customers</h5>
          <div class="count">
            <ICountUp :endVal="store.customers" />
          </div>
        </div>
        <div class="col-md-4">
          <h5>Inventory</h5>
          <div class="count">
            <ICountUp :endVal="store.inventory" />
          </div>
        </div>
        <div class="col-md-4">
          <h5>Transactions</h5>
          <div class="count">
            <ICountUp :endVal="store.transactions" />
          </div>
        </div>
      </div>
      <h6 class="border-bottom border-gray pb-2">Product Settings</h6>
      <div class="row mt-3">
        <div class="col-md-4 mb-4 mb-xl-0">
          Show Stock Level
          <div class="custom-control custom-switch">
            <input type="checkbox" v-model="store.showStockLevel" class="custom-control-input" :id="`stock-${index}`" @change="saveData(store)">
            <label
              class="custom-control-label" 
              :for="`stock-${index}`"
              v-html="store.showStockLevel ? 'Enabled' : 'Disabled'">
            </label>
          </div>
        </div>

        <div class="col-md-4 mb-4 mb-xl-0">
          Out of Stock Product
          <div class="custom-control custom-switch">
            <input type="checkbox" v-model="store.showOutOfStockSpecial" class="custom-control-input" :id="`outOfStockProduct-${index}`" @change="saveData(store)">
            <label
              class="custom-control-label" 
              :for="`outOfStockProduct-${index}`"
              v-html="store.showOutOfStockSpecial ? 'Special Order' : 'Hidden'">
            </label>
          </div>
        </div>

        <div class="col-md-4 mb-4  mb-lg-0">
          Show Competitors Level
          <div class="custom-control custom-switch">
            <input type="checkbox" v-model="store.showCompetitors" class="custom-control-input" :id="`competitors-${index}`" @change="saveData(store)">
            <label
              class="custom-control-label" 
              :for="`competitors-${index}`"
              v-html="store.showCompetitors ? 'Enabled' : 'Disabled'">
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  
  import AdminService from '@/api-services/admin.service';
  import ICountUp from 'vue-countup-v2';
  export default {
    name: 'PosDataSyncer',
    components: {
      ICountUp
    },
    data() {
      return {
        stores: [],
        saving: false
      };
    },
    computed: {
      slug() {
        return this.$store.state.business_slug;
      }
    },
    async mounted() {
      if(this.slug) {
        let response = await AdminService.getPosInfo();
        this.stores = response.data.stores;
      }
    },
    methods: {
      saveData(store) {
        let data = {
          storeId: store.storeId,
          showStockLevel: store.showStockLevel,
          showOutOfStockSpecial: store.showOutOfStockSpecial,
          showCompetitors: store.showCompetitors
        };
        this.saving = true;
        AdminService.savePosInfo(data).then(() => {
          this.saving = false;
        });
      }
    }
  };
</script>

<style lang="scss" scoped>
  $primary: #A02230;
  .heading {
    height: 80px;
    .h4 {
      color: $primary;
    }
  }
  .h4 {
    color: $primary;
  }
  .h3 {
    font-weight: 400;
  }
  .count {
    font-size: 34px;
    color: $primary;
  }
  .store-box:not(:last-child) {
    border-bottom: 1px solid #e5e5e5;
  }
</style>
