<template>
  <div class="product-details-box">
    <img v-if="!product" src="/icons/loader.gif" class="loader py-3">

    <div v-else class="container">
      <div id="productDetails">
        <div class="product-section">
          <div class="header-info mt-2">
            <div class="w-40">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb category">
                  <li
                    v-for="(breadcrumb, index) in breadcrumbs"
                    :key="'product-breadcrumb_' + index"
                    class="breadcrumb-item cursor-pointer"
                    :class="{ active: index === breadcrumbs.length - 1 }"
                    @click="redirectToBreadcrumbsItem(breadcrumb)">
                    {{ breadcrumb.title }}
                  </li>
                </ol>
              </nav>
            </div>
            <div class="w-60 flex-row justify-content-start align-items-baseline pr-8">
              <div v-if="product.promo_price" class="special alert alert-danger" role="alert">
                <span>SPECIAL</span>${{ product.promo_price }}
              </div>
            </div>
          </div>
          <div class="w-40" style="vertical-align: top; height: 400px;">
            <div class="product-view-box">

              <div id="product-preview">
                <ProductZoomer
                  :base-images="images"
                  :base-zoomer-options="zoomerOptions"
                />
              </div>

            </div>
          </div>
          <div class="w-60">
            <h2>{{ product.title }}</h2>
            <p class="model">
          <span>
            SKU <strong>#{{ product.sku }}</strong>
          </span>
              <span>
            Model <strong>#{{ product.model_number }}</strong>
          </span>
              <span>
            UPC <strong>#{{ product.upc }}</strong>
          </span>
            </p>
            <div class="row mb-4">
              <div class="col-md-5">
                <div class="card card-description regular-price">
                  <div class="title">
                    Regular Price
                  </div>
                  <div class="card-content">
                    ${{ product.price }}
                  </div>
                </div>
              </div>
              <div class="col-md-7" v-if="productCompetitors && productCompetitors.length">
                <div class="card card-description compare-prices">
                  <div class="title">
                    Compare Prices To
                  </div>
                  <div class="card-content d-flex flex-row p-0">
                    <img v-if="!productCompetitors" src="/icons/loader.gif" class="loader">
                    <div class="d-flex flex-column text-center py-2 competitor"
                    v-for="(competitor, index) in productCompetitors" :key="`competitors-item-${product.id}-${index}`">
                      <div>${{ competitor.price }}</div>
                      <div><img :src="competitor.logo"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card card-primary">
              <div class="card-body">
                <div class="card-title d-flex">
                  <span class="shop-location mr-2"></span> {{(product.num_inventory)?'IN-STORE PICKUP':'SPECIAL ORDER FROM VENDOR'}}
                 
                </div>
                <p class="model mb-0" v-if="product.num_inventory">
                  <span :class="{'text-danger':product.num_inventory >= 1 && product.num_inventory <= 5}">
                    <b>Qty Available:</b> {{product.num_inventory}} 
                  </span>
                </p>
                <!-- <h6>Deliver to EZ-AD - Canyon Country 91387</h6> -->
                <div v-if="businessDetails.show_stock_level" class="stock-text">
                  <template v-if="product.num_inventory >= 1 && product.num_inventory <= 5">
                    <!-- <span>ONLY {{ product.num_inventory }} Left In Stock</span> -->
                  </template>
                  <template v-else>
                    <template v-if="product.num_inventory <= 0">
                      <span v-if="businessDetails.show_oos_special && product.vendor_id" >
                        <!-- This product is out of stock, it will be shipped from the vendor. -->
                        This product is out of stock, but you can still order it! The vendor will ship it to your house.
                      </span>
                      <span v-else>Out of Stock</span>
                    </template>
                  </template>
                </div>
                <div class="row quantity">
                  <div class="col-md-12 col-lg-4 col-xs-12 align-items-center">
                    <change-quantity :qty="quantity" :cartItem="product" :limit="product.num_inventory"
                                     :special="product.num_inventory === 0 && !!product.vendor_id && businessDetails.show_oos_special"
                                     @quantityUpdated="quantityUpdated"/>
                    <span v-if="product.location">Store Location: {{ product.location }}</span>
                  </div>
                     <div class="col-md-12 col-lg-8 col-xs-12 align-items-center">
                     <button class="btn quick pickup">
                       <i class="fa fa-chevron-left icon" aria-hidden="true"></i> 
                       <p v-if="product.num_inventory && quantity <= product.num_inventory">
                         Purchase this product for quick pickup.
                       </p>
                       <p v-else>
                         This product will be shipped by the vendor.</p>
                        </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

         <div class="box-element align-items-stretch">
            <div class="w-50">
              <div class="card card-primary offers">
                <div class="card-header">Images & Videos</div>
                <div class="card-body video-gallery p-0">
                  <img v-if="!productVideos" src="/icons/loader.gif" class="loader mb-3">
                  <p v-if="productVideos && !productVideos.length">
                    No videos for this product
                  </p>
                  <div v-if="productVideos" class="video-player">
                    <div class="row">
                  
                        <div
                          v-for="video in productVideos"
                          :key="'product_video_' + video.id"
                          class="col-md-6 col-sm-6 col-xs-12 video-wrapper">
                          <div @click="changeVideo(video)" >
                            <img :src="video.thumbnail" class="thumbnail">
                            <img src="/icons/play.png" class="play">
                            <div class="video-title">
                              {{ video.name }}
                            </div>
                          </div>
                        </div>
                     
                  
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <div class="w-50 h-100">
              <div class="card card-primary">
                <div class="card-header">
                  Product Description
                </div>
                <p>{{productDescription}}</p>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer mt-3">
          <div id="product-description">
            <div class="w-100 pr-0">
              <!-- <div class="card card-primary offers">
                <div class="card-header">
                  Products Popularly Purchased
                </div>
                <div class="card-body offer">
                  <img
                    v-if="!popularProducts"
                    src="/icons/loader.gif"
                    class="loader">
                  <template v-if="popularProducts">
                    <swiper ref="popularProductsSlider" :options="swiperOption" class="products-slider">
                      <swiper-slide
                        v-for="(item, index) in popularProducts"
                        :key="'popular-products-' + index">
                        <product-item :item="item"/>
                      </swiper-slide>
                    </swiper>
                    <div class="swiper-button-prev" slot="button-prev">
                      <div class="swipe-prev" @click="popularProductsSwiper.slidePrev()"/>
                    </div>
                    <div class="swiper-button-next" slot="button-next">
                      <div class="swipe-next" @click="popularProductsSwiper.slideNext()"/>
                    </div>
                  </template>
                </div>
              </div> -->
            </div>

            <!-- <div class="w-100">
              <div class="card card-primary offers mb-0">
                <div class="card-header">
                  Favorite Products
                </div>
                <div class="card-body offer">
                  <img
                    v-if="!favouriteProducts"
                    src="/icons/loader.gif"
                    class="loader">
                  <template v-if="favouriteProducts">
                    <swiper ref="favouriteProductsSlider" :options="swiperOption" class="products-slider">
                      <swiper-slide
                        v-for="(item, index) in favouriteProducts"
                        :key="'favourite-products-' + index">
                        <product-item :item="item" :internal-api="false"/>
                      </swiper-slide>
                    </swiper>
                    <div class="swiper-button-prev" slot="button-prev">
                      <div class="swipe-prev" @click="favouriteProductsSlider.slidePrev()"/>
                    </div>
                    <div class="swiper-button-next" slot="button-next">
                      <div class="swipe-next" @click="favouriteProductsSlider.slideNext()"/>
                    </div>
                  </template>
                </div>
              </div>
            </div> -->

            <div class="w-100">
              <div class="card card-primary offers mb-0">
                <div class="card-header">
                  Customers Also Purchased
                </div>
                <div class="card-body offer">
                  <img
                    v-if="!similarProducts"
                    src="/icons/loader.gif"
                    class="loader">
                  <template v-if="similarProducts">
                    <swiper ref="similarProductsSlider" :options="swiperOption" class="products-slider">
                      <swiper-slide
                        v-for="(item, index) in similarProducts"
                        :key="'similar-products-' + index">
                        <product-item :item="item" :internal-api="true"/>
                      </swiper-slide>
                    </swiper>
                    <div class="swiper-button-prev" slot="button-prev">
                      <div class="swipe-prev" @click="similarProductsSwiper.slidePrev()"/>
                    </div>
                    <div class="swiper-button-next" slot="button-next">
                      <div class="swipe-next" @click="similarProductsSwiper.slideNext()"/>
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <video-lightbox ref="lightbox"/>
    </div>
  </div>
</template>

<script>
  import ProductApiService from '@/api-services/product.service';
  import BrandsApiService from '@/api-services/brands.service';

  export default {
    name: 'SingleProductPage',
    data() {
      return {
        // quantity: 0,
        breadcrumbs: null,
        productVideos: null,
        similarProducts: null,
        productCompetitors: null,
        swiperOption: {
          loop: true,
          slidesPerView: 'auto',
          spaceBetween: 0,
          draggable: true,
          allowTouchMove: true,
        },
        zoomerOptions: {
          zoomFactor: 3,
          pane: 'pane',
          hoverDelay: 300,
          move_by_click: false
        },
        productDescription: 'Is your home decor beginning to look a little boring and bland? Give it an upgrade with the rustic\n' +
        '                  charm and unique design of\n' +
        '                  this entertainment credenza from the Better Homes and Gardens Modern Farmhouse collection. Is your home decor beginning to look a little boring and bland? Give it an upgrade with the rustic\n' +
        '                  charm and unique design of\n' +
        '                  this entertainment credenza from the Better Homes and Gardens Modern Farmhouse collection.'
      };
    },
    computed: {
      product() {
        return this.$store.state.products.find(
          item => item.sku === this.$route.params.id
        );
      },
      popularProducts() {
        return this.$store.state.popularProducts;
      },
      favouriteProducts() {
        return this.$store.state.favouriteProducts;
      },
      popularProductsSwiper() {
        return this.$refs.popularProductsSlider.swiper;
      },
      similarProductsSwiper() {
        return this.$refs.similarProductsSlider.swiper;
      },
      favouriteProductsSlider() {
        return this.$refs.favouriteProductsSlider.swiper;
      },
      videoSwiper() {
        return this.$refs.videoSlider.swiper;
      },
      quantity: {
        get() {
          const cartItems = this.$store.state.cart.parcels;
          if (cartItems && cartItems.length) {
              let pickupParcel = cartItems.find(item => {
                  return item.type === 'pickup';
              });
              if ( !pickupParcel ) {
                  pickupParcel = {items: []};
              }
              const specialParcels = cartItems.filter(item => {
                  return item.type === 'special';
              });
              let specialItems = [];
              if (specialParcels && specialParcels.length) {
                  specialParcels.forEach(parcel => {
                      if (parcel.items && parcel.items.length) {
                          specialItems = [...specialItems, ...parcel.items];
                      }
                  });
              }
              const items = [...specialItems, ...pickupParcel.items];
              let cartItem = items.find(x => x.store_product_id === this.product.id);
              if (cartItem && cartItem.quantity) {
                return cartItem.quantity;
              }
              return 0;
          }
          else return 0;
        },
        set(val) {
          return val;
        }
      },
      preferences() {
        return this.$store.state.preferences;
      },
      businessDetails() {
        return this.$store.state.businessDetails;
      },
      images() {
        return {
          'normal_size':
            [
              {'id': '1', 'url': this.product.image_url}
            ]
        };
      }
    },
    methods: {
      changeVideo(video) {
        this.$refs.lightbox.changeVideo(video);
      },
      quantityUpdated(value) {
           this.quantity = value;
      },
      redirectToBreadcrumbsItem(breadcrumb) {
        if (!breadcrumb.path) {
          return;
        }
        this.$router.push(breadcrumb.path);
      },
      async fetchData() {
        let params = this.$route.params;

        if (!params.id) {
          return redirect('/');
        }

        let products = this.$store.state.products;
        let product = products.find(item => item.sku === params.id);

        if (!products.length || !product || !product.breadcrumbs) {
          await ProductApiService.getProduct(params.id).then(response => {
            if (!product) {
              product = response.data.data;

              product.competitors = null;
              product.similars = null;
              product.videos = null;

              this.$store.commit('addProduct', product);
            } else {
              product.breadcrumbs = response.data.data.breadcrumbs;
            }
          });
        }

        if (!this.popularProducts) {
          ProductApiService.getPopularProducts(product.sku).then(response => {
            let allProducts = [];

            response.data.data.forEach(item => {
              item.competitors = null;
              item.similars = null;
              item.videos = null;

              allProducts.push(item);
            });

            this.$store.commit('addProductsRange', allProducts);
            this.$store.commit('setPopularProducts', allProducts);

            let allSKUs = [];
            allProducts.forEach(item => {
              allSKUs.push(item.sku);
            });

            if (allSKUs.length) {
              ProductApiService.getCompetitorsForSKUList(allSKUs).then(
                response => {
                  this.$store.commit('setMultiCompetitors', response.data.data);
                }
              );
            }
          });
        }

        if (!product.competitors) {
          ProductApiService.getCompetitors(product.sku).then(response => {
            let payload = {
              productId: product.id,
              data: response.data.competitors,
            };
            this.$store.commit('setCompetitors', payload);
            this.productCompetitors = payload.data;
          });
        } else {
          this.productCompetitors = product.competitors;
        }

        if (!product.similars) {
          ProductApiService.getSimiliarProducts(product.sku).then(response => {
            let allSKUs = [];
            let similarProducts = {
              productId: product.id,
              data: response.data.data,
            };

            similarProducts.data.forEach(item => {
              allSKUs.push(item.upc);
            });

            if (allSKUs.length) {
              ProductApiService.getCompetitorsForSKUList(allSKUs).then(
                response => {
                  let competitors = response.data.data;

                  similarProducts.data.forEach(item => {
                    item.competitors = competitors[item.upc];
                  });

                  this.$store.commit('setSimilarProducts', similarProducts);
                  this.similarProducts = similarProducts.data;
                }
              );
            }
          });
        } else {
          this.similarProducts = product.similars;
        }

        if (!product.videos) {
          ProductApiService.getVideos(product.sku).then(response => {
            let payload = {productId: product.id, data: response.data.data};

            this.$store.commit('setProductVideos', payload);
            this.productVideos = payload.data;
          });
        } else {
          this.productVideos = product.videos;
        }

        if (!this.favouriteProducts) {
          ProductApiService.getFavouriteProducts().then(response => {
            let allProducts = [];

            response.data.data.forEach(item => {
              item.competitors = null;
              item.similars = null;
              item.videos = null;

              allProducts.push(item);
            });

            this.$store.commit('addProductsRange', allProducts);
            this.$store.commit('setFavouriteProducts', allProducts);

            let allSKUs = [];
            allProducts.forEach(item => {
              allSKUs.push(item.sku);
            });

            if (allSKUs.length) {
              ProductApiService.getCompetitorsForSKUList(allSKUs).then(
                response => {
                  this.$store.commit('setMultiCompetitors', response.data.data);
                }
              );
            }
          });
        }
      },
      async getBrandNameById(brandId) {
        let response = await BrandsApiService.getBrandById(+brandId);
        response = response.data.data;
        return response.brand_name;
      },
      async setBreadcrumbs() {
        let breadcrumbs = localStorage.getItem('product_breadcrumbs');
        breadcrumbs = JSON.parse(breadcrumbs);
        this.breadcrumbs = [];
        if (breadcrumbs.from === 'brands-id') {
          this.breadcrumbs[0] = {
            title: 'Brands',
            path: '/brands'
          };
          let brandName;
          if (breadcrumbs.params && breadcrumbs.params.brand) {
            brandName = breadcrumbs.params.brand.brand_name;
          } else {
            const brandId = breadcrumbs.fullPath.split('/')[2];
            if (brandId) {
              const brands = this.$store.state.brands && this.$store.state.brands.data;
              if (brands) {
                const brand = brands.find(brand => {
                  return brand.brand_id === +brandId;
                });
                if (brand) {
                  brandName = brand.brand_name;
                } else {
                  brandName = await this.getBrandNameById(brandId);
                }
              } else {
                brandName = await this.getBrandNameById(brandId);
              }
            }
          }
          this.breadcrumbs[1] = {
            title: brandName,
            path: breadcrumbs.fullPath
          };
          this.breadcrumbs[2] = {
            title: this.product.title
          };
        } else if (breadcrumbs.from === 'search') {
          this.breadcrumbs[0] = {
            title: 'Search Results',
            path: breadcrumbs.fullPath
          };

          this.breadcrumbs[1] = {
            title: this.product.title
          };
        } else {
          this.breadcrumbs[0] = {
            title: 'Home',
            path: breadcrumbs.fullPath
          };

          this.breadcrumbs[1] = {
            title: this.product.title
          };
        }
      }
    },
    async mounted() {
      window.scrollTo(0, 0);
      await this.fetchData();
      this.setBreadcrumbs();
      // let cartItem = this.$store.state.cart.filter(
      //   item => item.id === this.product.id
      // );
      // if(cartItem) this.quantity = cartItem.quantity;
    },
  };
</script>

<style scoped lang="scss">
  .card-primary {
    margin-bottom: 0 !important;
  }
</style>


<style lang="scss">
  @import '@/assets/scss/home.scss';

  // NOTE: We need this to hide control box of vue-product-zoomer
  .control-box {
    display: none !important;
  }
  h2{
    font-weight: bold;
  }
  .h-380{
      height: 380px!important;
  }
  .btn.quick.pickup {
    background: #f2f4f5;
    border: 1px solid #E7E7E7;
    text-align: left;
    padding: 5px 10px;
    width: 98%;
    .icon {
    background: #212529;
    background: #212529;
    color: #fff;
    font-size: larger;
    padding: 5px;
    position: inherit;
    border-radius: 5px;
    border: 1px solid #212529;
    }
    p {
      display: inline;
      color: #212529!important;
      margin-left: 10px;
      font-weight: 800;
      font-size: 12px;
    }
  }
  #container-zoomer-pane-container {
    left: 43% !important;
  }

  .pr-8 {
    padding-right: 84px;
  }

  .product-details-box {
    background: #f7f7f7;
    padding-top: 30px;
  }

  .card.card-primary > p > button {
    background: transparent;
    border: none;
    color: #A02230;
  }
  .card.card-primary .shop-location {
    background-image: url('data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMjAgMjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDYxICg4OTU4MSkgLSBodHRwczovL3NrZXRjaC5jb20gLS0+CiAgICA8dGl0bGU+R3JvdXA8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iR3JvdXAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEuMDAwMDAwLCAxLjAwMDAwMCkiPgogICAgICAgICAgICA8cGF0aCBkPSJNMTAuMTI0MTgxOCw4Ljk5NzU0NTQ1IEM5LjA0MjU0NTQ1LDguOTQzNTQ1NDUgOC4xODE4MTgxOCw4LjA1MDA5MDkxIDguMTgxODE4MTgsNi45NTQ1NDU0NSBDOC4xODE4MTgxOCw4LjA4NDQ1NDU1IDcuMjY2MjcyNzMsOSA2LjEzNjM2MzY0LDkgQzUuMDA2NDU0NTUsOSA0LjA5MDkwOTA5LDguMDg0NDU0NTUgNC4wOTA5MDkwOSw2Ljk1NDU0NTQ1IEM0LjA5MDkwOTA5LDguMDg0NDU0NTUgMy4xNzUzNjM2NCw5IDIuMDQ1NDU0NTUsOSBDMC45MTU1NDU0NTUsOSA4Ljg4MTc4NDJlLTE1LDguMTQ3NDU0NTUgOC44ODE3ODQyZS0xNSw2LjU0NTQ1NDU1IEwzLjI3MjcyNzI3LDAgTDEzLjA5MDkwOTEsMCBMMTYuMzYzNjM2NCw2LjU0NTQ1NDU1IiBpZD0iUGF0aCIgc3Ryb2tlPSIjQTAyMjMwIiBzdHJva2Utd2lkdGg9IjEuNjM2MzYzNjQiPjwvcGF0aD4KICAgICAgICAgICAgPHBvbHlsaW5lIGlkPSJQYXRoIiBzdHJva2U9IiNBMDIyMzAiIHN0cm9rZS13aWR0aD0iMS42MzYzNjM2NCIgcG9pbnRzPSIyLjQ1NDU0NTQ1IDkgMi40NTQ1NDU0NSAxNi4zNjM2MzY0IDkgMTYuMzYzNjM2NCI+PC9wb2x5bGluZT4KICAgICAgICAgICAgPHBhdGggZD0iTTE4LDEwLjYzNjM2MzYgQzE4LDEzLjE3MjcyNzMgMTMuOTA5MDkwOSwxNy4yNjM2MzY0IDEzLjkwOTA5MDksMTcuMjYzNjM2NCBDMTMuOTA5MDkwOSwxNy4yNjM2MzY0IDkuODE4MTgxODIsMTMuMTcyNzI3MyA5LjgxODE4MTgyLDEwLjYzNjM2MzYgQzkuODE4MTgxODIsOC4wMTgxODE4MiAxMS45NDU0NTQ1LDYuNTQ1NDU0NTUgMTMuOTA5MDkwOSw2LjU0NTQ1NDU1IEMxNS44NzI3MjczLDYuNTQ1NDU0NTUgMTgsOC4wMTgxODE4MiAxOCwxMC42MzYzNjM2IFoiIGlkPSJQYXRoIiBzdHJva2U9IiNBMDIyMzAiIHN0cm9rZS13aWR0aD0iMS42MzYzNjM2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSI+PC9wYXRoPgogICAgICAgICAgICA8Y2lyY2xlIGlkPSJPdmFsIiBmaWxsPSIjQTAyMjMwIiBmaWxsLXJ1bGU9Im5vbnplcm8iIGN4PSIxMy45MDkwOTA5IiBjeT0iMTAuNjM2MzYzNiIgcj0iMSI+PC9jaXJjbGU+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=');
    background-repeat: no-repeat;
    width: 20px;
    height: 20px;
    display: inline-block;
  }

  .card.card-primary > p > button:focus {
    box-shadow: none;
    outline: none;
  }

  .card.card-primary > .card-body {
    padding: 20px;
  }

  .card .card-body > h6 {
    font-size: 14px;
    margin-bottom: 15px;
    line-height: 16px;
    color: #3E80CE;
  }

  .card .card-body {
    .stock-text {
      font-size: 14px;
      margin-bottom: 15px;
      line-height: 16px;
      color: #979A9F;
      font-weight: bold;
    }
  }

  .actions > div > input {
    width: 80px;
    margin-right: 15px;
    border-radius: 5px;
    border: 1px solid #00000020;
  }

  .card.card-primary {
    .card-body {
      .swiper-container {
        border: none !important;

        .swiper-wrapper {
          .swiper-slide-active {
            .swiper-slide > .discounted-item {
              margin: 0 !important;
            }
          }
        }
      }
    }
  }

  .product-section {
    background: #fff;
    border-radius: 3px;
    border: 1px solid #e9e9e9;

    .special span {
      margin-right: 8px;
    }

    .box-element {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 30px 0 20px;

      .card {
        margin-left: 15px;
        margin-right: 15px;

        p {
          padding: 20px 30px;
          max-height: 170px;
          overflow: auto;
          font-size: 14px;
          line-height: 22px;
        }

        .video-player {
          max-height: 384px;
          overflow-y: scroll;
          padding: 15px;
          .row {
            .swiper-button-next {
              height: 100% !important;
              right: 0 !important;
              top: 22px;
            }

            .swiper-button-prev {
              height: 100% !important;
              left: 0 !important;
              top: 22px;
            }
          }
        }
      }
    }
  }

  .swiper-button-next,
  .swiper-button-prev {
    background: none;
  }
  .swipe-prev.pre,
  .swipe-next.nxt {
    height: 30px !important;
    width: 30px !important;
  }

  .video-gallery {
    // max-height: 190px;
    //overflow: hidden;
    //margin-top: 30px;

    > .row {
      margin-left: -10px;
      margin-right: -10px;
    }

    .video-wrapper {
      position: relative;
      padding-left: 10px;
      margin-bottom: 10px;
      padding-right: 10px;

      img.thumbnail {
        width: 100%;
        height: 100%;
        object-fit: cover;
        cursor: pointer;
      }

      img.play {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        cursor: pointer;
      }

      .video-title {
        position: absolute;
        background-color: rgba(0, 0, 0, 0.4);
        width: calc(100% - 20px);
        color: #fff;
        padding: 0 10px;
        left: 10px;
        bottom: 18px;
        font-size: 14px;
        font-weight: 700;
        line-height: 20px;
        font-family: 'Roboto';
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  }

  #productDetails .header-info > .w-40 {
    width: calc(40% - 4px);
  }

  #productDetails .header-info > .w-60 {
    width: calc(60% - 4px);
  }

  #product-description {
    padding: 10px 0 !important;

    .offers {
      margin-bottom: 30px !important;
    }

    p {
      padding: 15px !important;
    }
  }

  .product-view-box {
    display: flex;
    justify-content: space-between;

    #product-preview {
      flex: 3;
      border: 1px solid #e2e2e7;
      border-radius: 3px;
      margin-bottom: 0 !important;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 200px;
      min-height: 407px;

      img {
        width: 100%;
        object-fit: contain;
      }
    }

    .product-image {
      flex: 1;
    }
  }

  .image-magnifier__zoom {
    z-index: 999 !important;
    top: -40px !important;
    right: -390px !important;
    left: unset !important;
  }

  @media (max-width: 578px) {
    .pr-8 {
      padding-right: 0;
    }
    .justify-content-end {
      justify-content: flex-start !important;
    }
    #productDetails {
      .product-section {
        h2 {
          font-size: 22px;
        }
      }

      .product-view-box {
        flex-direction: column;
        flex-grow: 1;

        .product-image {
          order: 1;

          .card-body {
            .video-player {
              display: flex;
              margin-top: 20px;

              .video-wrapper {
                img {
                  min-width: 120px;
                }
              }
            }
          }
        }

        #product-preview {
          width: 100%;

          img {
            padding: 15px 0;
            max-height: 235px;
            height: auto;
          }
        }
      }

      #product-description {
        .w-60 {
          padding: 0 !important;
        }

        .w-40 {
          padding: 0 !important;
        }
      }
    }
  }

  @media (max-width: 767px) {
    #productDetails .header-info > .w-60 {
      display: flex !important;
      justify-content: flex-start !important;
    }
    .swiper-slide:first-of-type > .discounted-item {
      margin-left: 0 !important;
    }
    .products-slider.swiper-container {
      margin: 0 55px !important;
    }
    .products-slider.swiper-container + .swiper-button-prev {
      left: 10px;
    }
    .products-slider.swiper-container ~ .swiper-button-next {
      right: 10px;
    }
    .box-element .card-primary {
      margin-top: 30px;
    }
    #product-description {
      padding: 0 !important;
    }
    .box-element {
      margin-top: 0 !important;
    }
  }

  @media (max-width: 992px) {
    .box-element {
      flex-direction: column;

      .w-50 {
        width: 100% !important;

        .card-primary {
          margin-bottom: 30px !important;
        }
      }
    }
    .w-60 {
      h2 {
        font-size: 1.2rem;
        // font-weight: bold;
      }
    }
  }

  @media (max-width: 1199px) {
    .product-section {
      .box-element {
        .card {
          p {
            padding: 15px 15px 0 !important;
            font-size: 14px !important;
          }
        }
      }
    }
  }
</style>
