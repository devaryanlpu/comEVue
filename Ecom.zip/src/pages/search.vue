<template>
  <main>
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-6 pr0 left-side">
          <div class="card">
            <div class="card-body">
              <h5 class="mb-4">Filter Results</h5>
              <div class="filter-items mb-3">
                <filter-item
                  v-for="(item, index) in filterItems"
                  :key="index" :filterVal="item.value"
                  @click.native="removeFilter(item)"
                />
              </div>
              <div class="mb-3">
                <b-checkbox
                  id="checkbox-1"
                  name="promo-check"
                  @input="selectPromo()"
                  v-model="promo.selected"
                >
                  {{ promo.value }}
                </b-checkbox>
              </div>
              <div class="mb-3">
                <h6>Price</h6>
                <ul style="padding: 0;">
                  <li
                    v-for="price in priceRanges"
                    :key="price.min"
                    class="none-style-list price-range mb-1"
                    @click="selectPrice(price)"
                  >
                    {{ price.value }}
                    <span class="item-counts"> {{ price.matched_products }} </span>
                  </li>
                  <li class="none-style-list">
                    <!-- <div class="row"> -->
                      <b-input size="sm"
                        class="price-range-select price-min"
                        type="number" v-model="priceRange.min">
                      </b-input>
                      -
                      <b-input size="sm"
                        class="price-range-select price-max"
                        type="number" v-model="priceRange.max">
                      </b-input>

                      <b-button
                        class="btn btn-primary price-select-btn"
                        :disabled="parseFloat(priceRange.max) <= parseFloat(priceRange.min)"
                         @click="selectPrice(priceRange)">
                          <icon name="chevron-right" class="ml-auto"></icon>
                      </b-button>
                    <!-- </div> -->
                  </li>
                </ul>
              </div>
              <div class="mb-3 text-capitalize" :class="{'d-none': !departmentsHierarchy || !departmentsHierarchy.length}">
                <h6>Departments</h6>
                <b-tree-view
                  :data="departmentsHierarchy"
                  :contextMenu="false"
                  :renameNodeOnDblClick="false"
                  :contextMenuItems="[]"
                  ref="DepartmentstreeView"
                  @nodeSelect="departmentHierarchySelect"
                >
                </b-tree-view>
              </div>

              <div v-if="brands && brands.length" class="mb-3">
                <h6>Brands </h6>
                <div  style="max-height: 400px; overflow: auto;">
                  <ul style="padding: 0;">
                    <li class="none-style-list m-1">
                      <b-checkbox
                        v-for="brand in brands"
                        :key="brand.title"
                        class="m-1"
                        v-model="brand.selected"
                        @input="selectBrand(brand)"
                      >
                        {{ brand.brand_name }} ({{brand.matched_products}})
                      </b-checkbox>
                    </li>
                  </ul>
                </div>
              </div>

            </div>

          </div>
        </div>
        <div class="col-md-9 col-xs-12 pl-2 search-results" v-if="searchResults">
          <div class="row mb-3">
            <div class="col-md-8 col-sm-8 col-xs-12">
              <span>{{ searchResults.total }} Results for "<b>{{ displayKeyword }}</b>"</span>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12 d-flex justify-content-end">
              <v-select
                :options="sortOptions"
                v-model="sortby"
                @input="doSort"
                style="width: 100%; float: right;"
              ></v-select>
            </div>

          </div>
          <div class="row mb-3">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <v-pagination
                v-if="searchResults.last_page > 1"
                v-model="currentPage"
                :page-count="searchResults.last_page"
                :classes="bootstrapPaginationClasses"
                :labels="paginationAnchorTexts"
                @input="gotoPage"
                style="margin: 0;"
              />
            </div>
          </div>
          <div class="row" style="text-align: center; justify-content: center;" v-if="!searchResults.data">
            <spinner size="large" message="Waiting for the data..." />
          </div>
          <div class="row" v-if="searchResults.total > 0">
            <div
              v-for="item in searchResults.data"
              :key="item.upc_id"
              class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-xs-12 mb-3 p-0">
              <product-item :item="item" />
            </div>
          </div>
          <div class="row" style="justify-content: center" v-if="searchResults.total == 0">
            <span class="text-center">
              No products were found for this search
            </span>
          </div>
          <div class="row">
            <v-pagination
              v-if="searchResults.last_page > 1"
              v-model="currentPage"
              :page-count="searchResults.last_page"
              :classes="bootstrapPaginationClasses"
              :labels="paginationAnchorTexts"
              @input="gotoPage"
            />
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import FilterItem from '@/components/search/filter-item.vue';
import { bTreeView } from 'bootstrap-vue-treeview';
import Spinner from 'vue-simple-spinner';
import { paginationConfig } from '@/config/modules';
import VSelect from '@alfsnd/vue-bootstrap-select';
import { setTimeout } from 'timers';

export default {
  name: 'search',
  components: {
    FilterItem,
    Spinner,
    bTreeView,
    VSelect
  },
  props: [
    'keyword', 'deptId', 'deptName'
  ],
  data() {
    return {
      ...paginationConfig,
      pages: 0,
      currentPage: 1,
      perPage: 48,
      promo: {
        id: 'promo',
        value: 'Promo Products',
        check: false,
        selected: false,
      },
      priceRange: {
        id: 'custom_price',
        min: null,
        max: null,
        check: false
      },
      dept_id: this.deptId ? this.deptId : '',
      searchFilters: {
        search: this.keyword,
        dept_id: this.deptId ? this.deptId : '',
        limit: 48,
        start_price: 0,
        end_price: null,
        sort: '',
        brands: [],
        promo: 0,
        page: 1
      },
      filterItems: [],
      selectedBrands: [],
      sortOptions: [
        {value: "price-desc", text: "Price High to Low"},
        {value: "price-asc", text: "Price Low to High"},
        {value: "relevancy", text: "Relevancy"},
        {value: "latest", text: "New Arrivals"},
        {value: "title-asc", text: "Alphabetical"},
      ],
      sortby: { text: 'Relevancy', value: 'relevancy'},
      results: null,
      samplePriceRange: [
        {min: 0, max: 50},
        {min: 50, max: 150},
        {min: 150, max: 250},
        {min: 250, max: 500},
        {min: 500, max: null},
      ],
      currentSearch: this.keyword
    };
  },

  computed: {
    displayKeyword() {
      if (this.deptName && !this.keyword) {
          return this.deptName;
      }
      return this.keyword;
    },
    searchResults: {
      get: function() {
        if(this.$store.state.searchResults) {
          if(this.$store.state.searchResults.products.search != this.keyword) {
            this.$forceUpdate();
          }
          let arr = this.$store.state.searchResults.products;
          return arr;
        }
        else
          return null;
      },
      set: function(val) {
        this.results = val;
      }
    },
    departments() {
      if(this.$store.state.searchResults) {
        let arr = this.$store.state.searchResults.departments;
        let tree = [];
        tree.push({
          dept_id: null,
          name: 'All',
          children: []
        });
        arr.forEach(depart => {
          let node = {
            dept_id: depart.dept_id,
            dept_name: depart.name,
            name: `${depart.name} (${depart.matched_products})`,
            children: []
          };
          tree.push(node);
        });
        return tree;
      } else return [{ name: '', children: [] }];
    },
    departmentsHierarchy: {
      get: function() {
        if(this.$store.state.searchResults) {
          let arr = this.$store.state.searchResults.departments_hierarchy;
          console.log(this.$store.state.searchResults);
          let tree = [];
          arr.forEach(grand => {
            let node = null;
              node = {
                dept_id: grand.grand_parent.dept_id,
                name: `${grand.grand_parent.name.toLowerCase()} (${grand.grand_parent.matched_products})`,
                matched_products: grand.grand_parent.matched_products,
                children: []
              };

              grand.grand_parent.parent.forEach(parent => {
                  let parent_child = null;
                  parent_child = {
                    dept_id: parent.dept_id,
                    name: `${parent.name.toLowerCase()} (${parent.matched_products})`,
                    matched_products: parent.matched_products,
                    children: []
                  };

                  parent.childrens.forEach(children => {
                    let child = null;
                    child = {
                      dept_id: children.dept_id,
                      name: `${children.name.toLowerCase()} (${children.matched_products})`,
                      matched_products: children.matched_products
                    };
                    parent_child.children.push(child);
                  });
                node.children.push(parent_child);
              });

              tree.push(node);
          });
          return tree.sort((a, b) => { return b.matched_products - a.matched_products; });
        } else return [{ name: '', children: [] }];
      },
      set: function() {
        setTimeout(() => {
          this.formatDepartmentsTreeview();
        }, 1000);
      }
    },

    brands() {
      if(this.$store.state.searchResults) {
        let arr = this.$store.state.searchResults.brands;
        let temp = [];
        arr.forEach(item => {
          temp.push({
            ...item,
            id: 'brand',
            check: false,
            selected: false,
            value: item.brand_name
          });
        });
        return temp.sort((a, b) => { return b.matched_products - a.matched_products; });
      } else return [];
    },

    priceRanges() {
      if(this.$store.state.searchResults) {
        let arr = this.$store.state.searchResults.priceRanges;
        let temp = [];
        arr.forEach(item => {
          let min = this.samplePriceRange[item.range].min;
          let max = this.samplePriceRange[item.range].max;
          temp.push({
            ...item,
            id: 'price',
            check: false,
            min: min,
            max: max,
            value: !max ? 'more than $500' : `$${min} - $${max}`
          });
        });
        return temp;
      } else return null;
    },

    isValidPriceRange() {
      return this.priceRange.max > this.priceRange.min;
    }
  },

  watch: {
  },

  async mounted() {
    if(!this.results) {
      await this.$store.dispatch("clearSearch");
      // pointless? it's calling this THEN filter_search right after.
      /*
      await this.$store.dispatch("search", {
        search: this.keyword,
      });
      */
      this.filterItems = [];

      this.initFilter();
      await this.getSearch();
    }
    this.departmentsHierarchy = this.departmentsHierarchy;
  },

  updated() {
    if(this.currentSearch != this.keyword) {
      this.currentSearch = this.keyword;
      this.initFilter();
    }
  },
  methods: {
    initFilter() {
      this.promo.selected = false;
      this.promo.check = false;
      this.searchFilters = {
        search: '',
        dept_id: null, //this.deptId ? this.deptId : null,
        limit: 48,
        start_price: 0,
        end_price: null,
        sort: this.sortby.value,
        brands: [],
        promo: this.promo.selected ? 1 : 0,
        page: 1
      };
      this.filterItems = [];
    },
    gotoPage() {
      // this.initFilter();
      this.searchFilters.page = this.currentPage;
      this.getSearch();
    },
    doSort() {
      if ( this.searchFilters.sort != this.sortby.value ) {
          this.searchFilters.sort = this.sortby.value;
          this.getSearch();
      }
    },
    departmentHierarchySelect(node, isSelected) {
      if(isSelected) {
        this.searchFilters.dept_id = node.data.dept_id;
        this.getSearch();
      }
    },
    selectBrand(item) {
      // this.initFilter();
      if(item.selected) {
        this.selectedBrands.push(item.brand_id);
        this.addToFilter(item);
      } else {
        this.selectedBrands = this.selectedBrands.filter(function(ele){
          return item.brand_id != ele;
        });
        this.removeFilter(item);
      }
      this.searchFilters.brands = this.selectedBrands;
      this.getSearch();
    },
    selectPrice(price) {
      this.addToFilter(price);
      this.searchFilters.start_price = price.min;
      this.searchFilters.end_price = price.max;
      this.getSearch();
    },
    selectPromo() {
      if(this.promo.selected) {
        this.searchFilters.promo = 1;
        this.addToFilter(this.promo);
      } else {
        this.searchFilters.promo = 0;
        this.removeFilter(this.promo);
      }
      this.getSearch();
    },
    addToFilter(item) {
      item.check = !item.check;
      if(item.check) {
        if(item.id === 'price' || item.id === 'custom_price')
          this.filterItems = this.filterItems.filter(function(ele) {
            return ele.id !== 'price' && ele.id !== 'custom_price';
          });
        if(item.id === 'custom_price') {
          this.priceRange.check = false;
          if(this.priceRange.min && !this.priceRange.max)
            this.priceRange.value = `More than $${this.priceRange.min}`;
          else if(!this.priceRange.min && this.priceRange.max)
            this.priceRange.value = `Less than $${this.priceRange.max}`;
          else
            this.priceRange.value = `$${this.priceRange.min} - $${this.priceRange.max}`;
        }
        this.filterItems.push(item);
      } else {
        this.removeFilter(item);
      }
    },
    removeFilter(item) {
      this.filterItems = this.filterItems.filter(function(ele) {
        return ele !== item;
      });
      if(item.id === 'price' || item.id === 'custom_price') {
        this.searchFilters.start_price = 0;
        this.searchFilters.end_price = null;
      } else if(item.id === 'brand') {
        this.searchFilters.brands = this.searchFilters.brands.filter(function(ele) {
          return ele !== item.brand_id;
        });
        this.brands.forEach(brand => {
          if(item.brand_id === brand.brand_id)
            brand.selected = false; brand.check = false;
        });
      } else if(item.id == 'promo') {
        this.promo.check = false;
        this.promo.selected = false;
        this.searchFilters.promo = 0;
      }
      this.getSearch();
    },
    async getSearch() {
      // if using a deptId with no keyword, make the server search all items in department
      if (this.deptId && !this.keyword) {
        this.searchFilters.search = "dept:" + this.deptId;
      } else {
        this.searchFilters.search = this.keyword;
      }
      await this.$store.dispatch('filter_search', this.searchFilters);
      this.$forceUpdate();
    },
    formatDepartmentsTreeview() {
      if(this.departmentsHierarchy && this.departmentsHierarchy.length < 4 && this.$refs.DepartmentstreeView) {
        for(let i = 0; i < 4; i++) {
          let dep = this.$refs.DepartmentstreeView.$refs.rootNodes[i];
          if(dep) {
            dep.expand();
          } else {
            break;
          }
        }
      }
    }
  },
};
</script>

<style scoped>
  .discounted-item {
    width: auto !important;
    margin: 0 5px !important;
  }

  .promo-check {
    font-size: 16px;
  }

  .none-style-list {
    list-style: none;
  }

  li {
    font-size: 12px;
  }

  .price-range {
    color: #A02230;
    cursor: pointer;
  }

  .tree-view {
    font-size: 12px;
  }

  .item-counts {
    font-size: 11px;
    color: grey;
  }

  .item-counts::before {
    content: '(';
  }
  .item-counts::after {
    content: ')';
  }

  .price-range.selected {
    font-weight: 500;
  }

  .price-range-select {
    display: inline-block;
    width: 70px;
    padding: 0;
    font-size: 12px;
    height: 25px;
    text-align: center;
  }

  .price-range-select.price-min {
    margin-right: 5px;
  }

  .price-range-select.price-max {
    margin-left: 5px;
  }

  .price-select-btn {
    padding: 0px 10px;
    margin-left: 10px;
    height: 25px;
  }

  .departments-list.active {
    color: #48ce3d;
  }

  li.indent-2 {
    margin-left: 10px !important;
  }

  li.indent-2::before, li.indent-3::before {
    content: '↳';
    /* content: '\2713'; */
    margin-right: 5px;
  }

  li.indent-3 {
    margin-left: 20px !important;
  }

  .v-select {
    width: 150px;
  }
</style>


