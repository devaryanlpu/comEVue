<template>
  <div id="wrapper">
    <div class="container-fluid">
      <div class="card card-primary mb-5">
        <div class="card-header">Create New Password</div>
        <div class="card-body flex-column">
          <b-form @submit.prevent="submitForm">
            <div class="form-group">
              <label for="code">Verification code*</label>
              <input ref="code" type="text" class="form-control" />
            </div>
            <div class="form-group">
              <label for="password">New Password*</label>
              <input ref="password" type="password" class="form-control" />
            </div>
            <div class="form-group">
              <label for="confirmPassword">Re-enter Password*</label>
              <input ref="confirmPassword" type="password" class="form-control" />
            </div>
            <button class="btn btn-primary w-100">Continue</button>
          </b-form>
        </div>
      </div>
    </div>
    <!-- <footer>
      <hr />
      <div class="container py-0">
        <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them.</p>
      </div>
    </footer> -->
  </div>
</template>

<script>
import AuthApiService from "@/api-services/auth.service";
export default {
  name: "forgot-password",
  methods: {
    submitForm() {
      const code = this.$refs.code.value;
      const password = this.$refs.password.value;
      const confirmPassword = this.$refs.confirmPassword.value;

      if (!code) {
        alert("Please enter varification code");
        return;
      }
        console.log(code);
        console.log(password);
        console.log(confirmPassword);
      if (!password || !confirmPassword) {
        alert("Please enter password");
        return;
      }
      if (password !== confirmPassword) {
        alert("Password does not match");
        return;
      }
      AuthApiService.resetPassword(code, password).then(
        () => {
          this.$router.push('/login');
        },
        error => {
          console.log(error);
          alert("Something went wrong, Please try again later");
        }
      );
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/assets/scss/auth.scss";
</style>