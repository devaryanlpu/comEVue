<template>
  <div id="wrapper">
    <div class="container-fluid">
      <div class="card card-primary mb-5">
        <div class="card-header">Password Assistance</div>
        <div class="card-body flex-column">
          <b-form @submit.prevent="submitForm" class="needs-validation">
            <div class="form-group mb-1">
              <label for="email">Enter the email address associated with your account.</label>
              <input
                ref="email"
                type="email"
                class="form-control"
              />
            </div>
            <div v-if="errorMsg" class="invalid-feedback mb-3 mt-0">{{ errorMsg }}</div>
            <button class="btn btn-primary w-100">Continue</button>
          </b-form>
        </div>
      </div>
    </div>
    <!-- <footer>
      <hr />
      <div class="container py-0">
        <p>All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them.</p>
      </div>
    </footer> -->
  </div>
</template>

<script>
import AuthApiService from '@/api-services/auth.service';
export default {
  name: 'forgot-password',
  data() {
    return {
      errorMsg: ''
    };
  },
  methods: {
    submitForm() {
      AuthApiService.forgotPassword(this.$refs.email.value)
        .then(() => {
          this.errorMsg = '';
          this.$router.push('/reset-password');
        })
        .catch(error => {
          this.errorMsg = error.response.data.errors.email[0];
        }
      );
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/assets/scss/auth.scss";
.invalid-feedback {
  display: block !important;
}
</style>