<template>
  <main>
    <section>
      <div class="container">
        <div class="mb-3 d-flex align-items-center justify-content-between">
          <h4 style="flex: 1;" class="d-flex align-items-center">Your Cart <span v-if="cart" class="badge badge-number ml-3">{{ totalItems }}</span></h4>
          <button v-if="totalItems > 0" id="submit" type="button" @click="submit" class="btn btn-primary" :disabled="!loggedInUser || isSubmitting">
            <span :class="{'d-none':!isSubmitting}" class="spinner-border spinner-border-sm mr-3" role="status" aria-hidden="true"></span>
            Continue
          </button>
        </div>
        <div class="row" v-if="totalItems > 0">
          <div class="mb-5 mb-lg-0 col-lg-7">
            <div>
              <!-- NORMAL ITEMS -->
              <div class="cart card card-primary mt-2 mb-2" v-if="normalItems && normalItems.items && normalItems.items.length">
                <ul class="nav nav-tabs" :class="{'disabled': isSubmitting}">
                  <li class="nav-item" v-if="enabledTabs.pickup" :key="'pickup'" @click="setActiveTab(0)">
                    <a href="javascript:void(0)" class="nav-link" :class="{'active' : activeTab === 0}">
                      <div class="tab-icon-pickup"></div>
                      Pick up in Store
                    </a>
                  </li>
                  <li class="nav-item" v-if="enabledTabs.delivery" :key="'delivery'" @click="setActiveTab(1)">
                    <a href="javascript:void(0)" class="nav-link" :class="{'active' : activeTab === 1}">
                      <div class="tab-icon-delivery"></div>
                      Local Delivery
                    </a>
                  </li>
                  <li class="nav-item" v-if="enabledTabs.shipping" :key="'shipping'" @click="setActiveTab(2)">
                    <a href="javascript:void(0)" class="nav-link" :class="{'active' : activeTab === 2}">
                      <div class="tab-icon-shipping"></div>
                      Shipping
                    </a>
                  </li>
                </ul>
                <div class="card-body items flex-column py-0">
                  <div v-for="item in normalItems.items" :key="item.sku" class="item" :class="{'disabled': isSubmitting}">
                    <div class="img-wrapper">
                      <img :src="item.image_url" class="img-fluid">
                    </div>
                    <router-link class="name"
                                 :to="{ name: 'products-id', params: { id: item.sku, title: urlFriendly(item.title) } }">
                      {{ item.title }}
                    </router-link>
                    <change-quantity :qty="item.quantity"
                                     :special="item.num_inventory < 1 && !!item.vendor_id"
                                     :cart-item="item"
                                     :limit="item.num_inventory"
                                     :ui-limit="item.num_inventory"
                                     :special-modify="0" />
                    <div class="price">${{ +(item.price * item.quantity).toFixed(2) }}</div>
                  </div>
                </div>
              </div>

              <!-- SPECIAL ITEMS -->
              <template v-if="specialItems && specialItems.length">
                <div class="cart card card-primary">
                  <div class="card-header">
                    Shipping Directly From Vendor
                    <div class="badge badge-danger ml-3 align-items-center d-flex px-2" style="position:absolute;right:10px">3-5 Day Shipping</div>
                  </div>
                  <div class="card-body items flex-column py-0">
                    <div v-for="(specialItem, i) in specialItems" :key="i">
                      <div v-for="item in specialItem.items" :key="item.sku" class="item">
                        <div class="img-wrapper">
                          <img :src="item.image_url" class="img-fluid">
                        </div>
                        <div class="name">
                          <router-link
                            :to="{ name: 'products-id', params: { id: item.sku, title: urlFriendly(item.title) } }">
                            {{ item.title }}
                          </router-link>
                          <div class="tooltip-wrapper">
                            <div class="small">Special Order! <img src="/icons/info_icon.png"/></div>
                            <div class="tooltip">
                              This item is being shipped from its vendor
                            </div>
                          </div>
                        </div>
                        <change-quantity
                          :qty="item.quantity"
                          :special="item.num_inventory < 1 && !!item.vendor_id"
                          :cart-item="item"
                          :limit="item.num_inventory"
                          :special-modify="1" />
                        <div class="price">${{ +(item.price * item.quantity).toFixed(2) }}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </template>

              <!-- TOTALS -->
              <div class="totals" v-if="cart && totalItems > 0">
                <div v-if="cart.tax > 0">
                  Subtotal: <span class="n">${{ cart.subtotal }}</span>
                </div>
                <div v-if="cart.tax > 0">
                  Tax: <span class="n">${{ cart.tax }}</span>
                </div>
                <div v-if="typeName() === 'shipping' && cart.shipping_fee > 0">
                  Shipping: <span class="n">${{ cart.shipping_fee }}</span>
                </div>
                <div v-if="typeName() === 'delivery' && cart.delivery_fee > 0">
                  Delivery: <span class="n">${{ cart.delivery_fee }}</span>
                </div>
                <div>
                  Total: <span class="n">${{ typeName() === 'pickup' ? cart.total : typeName() === 'shipping' ? cart.total_with_shipping : cart.total_with_delivery }}</span>
                </div>
              </div>
              
              <img v-if="!cart" src="/icons/loader.gif" class="loader py-3">
            </div>
          </div>
          <div class="col-lg-5">
            <div class="card checkout-options">
              <div class="card-body">
                <cart-member @userInfo="memberInfo" @memberInfoChanged="updateMember" ref="cartMember" :isDisabled="isSubmitting" />
                <div v-if="loggedInUser">
                  <div v-if="activeTab === 0 && businessDetails.pickup_payment === 'store'" :key="'pickup'" class="mt-3">
                    Payment will be due at time of item pickup.
                  </div>
                  <div v-if="!specialItems.length && activeTab === 1" :key="'delivery'" class="mt-3">
                    <div class="card-title">Shipping Address</div>
                    <div class="mb-2 label">Just Enter Address &amp; Zipcode… <span class="text-primary">We’ll do the rest</span></div>
                    <div class="row">
                      <div class="col-md-8 mb-3 mb-md-0">
                        <input :disabled="isSubmitting" v-model="addressModel.address" type="text" class="form-control" name="address" placeholder="Please enter your address">
                      </div>
                      <div class="col-md-4">
                        <input :disabled="isSubmitting" v-model="addressModel.zip" type="text" class="form-control" name="zip" placeholder="ZIP Code">
                      </div>
                    </div>
                  </div>
                  <div v-if="specialItems.length || activeTab === 2" :key="'shipping'" class="mt-3">
                    <div class="card-title">Shipping Address</div>
                    <form ref="shippingForm">
                      <div class="row">
                        <div class="col-sm-6 col-xs-12">
                          <label class="form-check-label">
                            Address line 1
                          </label>
                          <input :disabled="isSubmitting" v-model="addressModel.address" type="text" class="form-control" name="address" placeholder="Address line 1">
                        </div>
                        <div class="col-sm-6 col-xs-12">
                          <label class="form-check-label">
                            Address line 2 (optional)
                          </label>
                          <input :disabled="isSubmitting" v-model="addressModel.address2" type="text" class="form-control" name="address2" placeholder="Address line 2">
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-6 col-xs-12">
                          <label for="city" class="mb-0 mt-3">City</label>
                          <input :disabled="isSubmitting" type="text" v-model="addressModel.city" class="form-control" id="city" name="city" placeholder="City">
                        </div>
                        <div class="col-sm-6 col-xs-12">
                          <label for="state" class="mb-0 mt-3">State/Province/Region: </label>
                          <input :disabled="isSubmitting" v-model="addressModel.state" type="text" class="form-control" id="state" name="state" placeholder="State">
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-6 col-xs-12">
                          <label for="inputCountry" class="mb-0 mt-3">Country/Region </label>
                          <select :disabled="isSubmitting" v-model="addressModel.country" id="inputCountry" class="form-control" name="country">
                            <option selected>USA</option>
                            <option>...</option>
                          </select>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                          <label class="mb-0 mt-3">Zip</label>
                          <input :disabled="isSubmitting" v-model="addressModel.zip" type="text" class="form-control" name="zip" placeholder="ZIP Code">
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>

            <!-- need a SINGLE ELEMENT for stripe elements, we cannot have one in each tab.
                  if you try and change this it WILL break. also if use v-if the element will not
                  exist, making the refs fail. so use display:none. -->

              <div class="cc-block" :style="{display: (activeTab !== 0 || businessDetails.pickup_payment !== 'store') ? 'block' : 'none'}">
              <div class="card-title">Payment</div>
              <div ref="card_element"></div>
              <div ref="card_errors" role="alert" v-if="cardError.length > 0">
                {{ cardError }}
              </div>
            </div>
          </div>
        </div>
        <div v-else>
          Cart is empty. Browse the website and add the things you like!
        </div>
      </div>
    </section>
  </main>
</template>

<script>
  import OrderApiService from '../api-services/order.service';
  import AuthController from '../controllers/auth.controller';
  import HomePageService from '@/api-services/homepage.service';

  import vstate from '../store/state';

  let stripe = null, elements = null, card = null;

  export default {
    name: 'CheckoutPage',
    data() {
      return {
        activeTab: 0,
        addressModel: {
          address: '',
          address2: '',
          zip: '',
          city: '',
          state: '',
          country: '',
        },
        displayNewAccountSection: false,
        isSubmitting: false,
        memberInfo: {},
        loggedInUser: AuthController.checkAuthStatus(),
        cardError: ''
      };
    },
    computed: {
      specialItems() {
        const cartItems = this.$store.state.cart.parcels;
        if (cartItems && cartItems.length) {
          const specialItems = cartItems.filter(item => {
            return item.type === 'special';
          });
          return specialItems;
        }
        return [];
      },
      normalItems() {
        const cartItems = this.$store.state.cart.parcels;
        if (cartItems && cartItems.length) {
          const pickupItems = cartItems.find(item => {
            return item.type === 'pickup';
          });
          return pickupItems;
        }
        return [];
      },
      cart() {
        return this.$store.state.cart;
      },
      totalItems() {
        return this.$store.state.cartItemCount;
      },
      businessDetails: {
        get() {
          return this.$store.state.businessDetails;
        },
        set(val) {
          return val;
        }
      },
      enabledTabs() {
        if (this.cart && this.cart.checkout_types) {
          const ct = this.cart.checkout_types;
          return {
            pickup: ct.indexOf('pickup') >= 0,
            delivery: ct.indexOf('delivery') >= 0,
            shipping: ct.indexOf('shipping') >= 0
          };
        } else {
          // default to business details at first
          return {
            pickup: this.businessDetails.pickup_enabled,
            delivery: this.businessDetails.delivery_enabled,
            shipping: this.businessDetails.shipping_enabled
          };
        }
      }
    },
    async mounted() {
      // Setting businessDetails again from API to Vuex Store if undefined (sorry good js)
      if(!Object.keys(this.businessDetails).length) {
        let resp = await HomePageService.getBusinessDetails();
        this.$store.commit('setBusinessDetails', resp.data.data);
      }
      // Setting the active tab based on fulfillment options
      this.activeTab = this.businessDetails.pickup_enabled ? 0 : this.businessDetails.delivery_enabled ? 1 : 2;

      if (card === null) {
        stripe = Stripe(vstate.stripe_publishable, {stripeAccount: this.businessDetails.stripe_account_id});
        elements = stripe.elements();
        card = elements.create('card');
      }
      card.mount(this.$refs.card_element);
    },
    methods: {
      setActiveTab(n) {
        this.activeTab = n;
      },
      urlFriendly(value) {
          return value.replace(/[ /]/g, '+');
      },
      updateMember(member) {
        this.memberInfo = member;
      },
      async submit() {
        /*if (this.businessDetails.pickup_payment == 'store' && this.activeTab === 0) {
          // no card required
          this.internalSubmit({provider: 'credit-card'});
          return;
        }*/
        const {token, error} = await stripe.createToken(card);
        this.cardError = '';
        this.isSubmitting = true;
        card.update({disabled: true});
        if (error) {
          this.cardError = error.message;
          this.isSubmitting = false;
          card.update({disabled: false});
        } else {
          this.internalSubmit({
            provider: 'credit-card',
            stripe_token: token.id
          });
        }
      },
      typeName() {
        switch (this.activeTab) {
          case 0: return 'pickup';
          case 1: return 'delivery';
          case 2: return 'shipping';
        }
        return '';
      },
      internalSubmit(otherProps) {        
        OrderApiService.submitCustomerOrder({
          type: this.typeName(),
          member: this.memberInfo, // first_name, last_name, telephone, email
          address: this.addressModel, // address, address2, city, state, zip, country
          ...otherProps
        }).then(res => {
          this.isSubmitting = false;
          card.update({disabled: false});
          if (res.data.order) {
            this.clearCartInfo();
            res.data.loginKeep = false;
            res.data.order = {}; // pointless to have this in auth data
            AuthController.login(res.data);
            this.$router.push({name: 'settings-orders'});
          }
        }).catch(err => {
          this.isSubmitting = false;
          card.update({disabled: false});
          this.$refs.cartMember.showErrors(err.response.data.errors);
        });

      },
      clearCartInfo() {
        this.$store.commit('setCartItems', {});
        this.memberInfo = {};
        if ( this.$refs.cartMember ) {
          this.$refs.cartMember.clearFields();
        }
        if ( this.$refs.memberDelivery ) {
          this.$refs.memberDelivery.clearFields();
        }
        if ( this.$refs.memberShipping ) {
          this.$refs.memberShipping.clearFields();
        }
      }
    }
  };
</script>

<style lang="scss">
  @import '@/assets/scss/checkout.scss';

  
  .cc-block {
    margin-top: 15px;
    padding: 15px 30px;
    background-color: #fff;
    border: 1px solid rgba(0, 0, 0, 0.125);
    border-radius: 10px;
  }

  .card-title {
    color: #2f3540;
    font-size: 20px;
    line-height: 24px;
    font-weight: bold;
    font-family: 'Roboto';
    border-bottom: 1px solid rgba(0, 0, 0, 0.125);
    margin-bottom: 15px;
    padding-bottom: 10px;
  }
  .card-wrapper {
    background: #FFFFFF;
    border: 1px solid #E8E8E8;
    box-sizing: border-box;
    border-radius: 13px;
    padding: 15px;

    .card-primary {
      border-radius: 10px;

      .card-header {
        border-radius: 10px 10px 0 0;
        display: flex;
        flex-direction: column;
        h5 {
          margin-bottom: 0;
          font-size: 16px;
          line-height: 24px;
          color: #212529;
        }

        h6 {
          margin-bottom: 0;
          font-size: 14px;
          line-height: 16px;
          color: #A02230;
        }
      }

      > .card-body {
        padding: 30px 16px;

        .item {
          .img-wrapper {
            border: 1px solid #E8E8E8;
            border-radius: 4px;
          }

          .price {
            flex: 1;
            justify-content: flex-end;
            display: flex;
          }

          a {
            p {
              font-size: 14px;
              line-height: 24px;
            }
          }
        }
      }
    }

    span {
      display: flex;
      justify-content: flex-end;
      margin: 25px 0 5px;
      padding: 0 15px;

      h5 {
        font-size: 20px;
        line-height: 24px;
        color: #ed672f;
      }
    }
  }

  .totals {
    text-align: right;
    padding: 30px;
    > div {
      margin-bottom: 5px;
      > span {
        font-size: 20px;
        margin-left: 7px;
      }
    }
  }

  .nav-tabs {
    .nav-link {
      [class^=tab-icon] {
        width: 38px;
        height: 38px;
        background-size: 100% auto;
        background-repeat: no-repeat;
        background-position: center center;
        margin-right: 10px;
      }
      .tab-icon-pickup {
        background-image: url('/images/checkout/pickup_orange.svg');
      }
      .tab-icon-delivery {
        background-image: url('/images/checkout/delivery_orange.svg');
      }
      .tab-icon-shipping {
        width: 68px;
        background-image: url('/images/checkout/shipping_orange.svg');
      }
      &.active .tab-icon-pickup {
        background-image: url('/images/checkout/pickup.svg');
      }
      &.active .tab-icon-delivery {
        background-image: url('/images/checkout/delivery.svg');
      }
      &.active .tab-icon-shipping {
        background-image: url('/images/checkout/shipping.svg');
      }
    }
  }

  .tooltip-wrapper {
    position: absolute;
    padding-bottom: 10px;
    bottom: 0;

    > .small {
      color: #ed672f;
      cursor: pointer;
    }

    .tooltip {
      display: none;
      position: absolute;
      background: #fff;
      width: 250px;
      font-size: 12px;
      border-radius: 3px;
      line-height: 15px;
      padding: 8px;
      left: 0;
      top: 25px;
      border: 1px solid #ccc;

      a {
        color: #ed672f !important;
      }

      &:after, &:before {
        bottom: 100%;
        left: 50px;
        border: solid transparent;
        content: " ";
        height: 0;
        width: 0;
        position: absolute;
        pointer-events: none;
      }

      &:after {
        border-color: rgba(255, 255, 255, 0);
        border-bottom-color: #fff;
        border-width: 5px;
        margin-left: -5px;
      }

      &:before {
        border-color: rgba(204, 204, 204, 0);
        border-bottom-color: #ccc;
        border-width: 6px;
        margin-left: -6px;
      }

      a {
        font-size: 12px;
      }
    }

    &:hover {
      .tooltip {
        display: block;
        opacity: 1;
      }
    }
  }

  .checkout-options {
    label, .label {
      font-size: 14px;
      color: #2F3540;
    }
  }

  .tabs .tab-content input {
    height: 38px;
    background: transparent !important;

    &::placeholder {
      color: #999797;
    }
  }
  .StripeElement + div[role=alert] {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
    font-size: 14px;
    position: relative;
    padding: .75rem 1.25rem;
    margin-bottom: 1rem;
    border: 1px solid transparent;
    border-radius: .25rem;
    margin-top: 10px;
  }

  @media (max-width: 767px) {
    .card-wrapper {
      .card-primary .card-header {
        padding: 15px 20px;
        h5 {
          font-size: 13px;
          line-height: 17px;
          font-weight: normal;
        }
        h6 {
          font-size: 12px;
        }
      }
      .tooltip-wrapper {
        bottom: 26px;
        left: 18px;
        padding: 0;
      }
      > span {
        margin: 0;
        &:first-of-type {
          margin-top: 20px;
        }
        h5 {
          font-size: 18px;
        }
      }
    }
    .btn-outline-success {
      padding: 5px 10px !important;
    }
    .google-radio {
      padding-left: 15px !important;
    }
  }

</style>
