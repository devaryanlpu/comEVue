<template>
  <main>
    <div class="container">
      <div class="row">
        <h1>TERMS & POLICIES</h1>
      </div>
      <div v-html="content"></div>
    </div>
  </main>
</template>

<script>
  export default {
    name: 'Terms',
    data() {
      return {
        content: '<div class="row">\n' +
          '<div class="block">\n' +
          '<div class="tb-wysiwyg-container"><p>\n' +
          '&nbsp;\n' +
          '</p><p>\n' +
          '<strong><u>General Terms and Conditions&nbsp;- <em>Obermeier Hardware Co.</em></u></strong>\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '1. ACCEPTANCE OF TERMS\n' +
          '</p><p>\n' +
          'These terms and conditions of use (the “<strong>Terms and Conditions</strong>”) apply to the website located at&nbsp;//www.hillsflatlumber.com/ and/or its mobile applications. The Site is maintained by or on behalf of <strong><em><u>Obermeier Hardware Co.</u></em></strong> Your use of the Site constitutes your unconditional agreement to follow and be bound by these Terms and Conditions. IF YOU DO NOT ACCEPT THESE TERMS AND CONDITIONS OF USE, PLEASE DO NOT USE THIS SITE.\n' +
          '</p><p>\n' +
          '  The Company reserves the right to modify these Terms and Conditions at any time by posting revised Terms and Conditions on the Site without prior notice. You should visit this page from time to time to review the then current Terms and Conditions. Your continued use of this Site following any such modification will signify your unconditional acceptance of the Terms and Conditions, as modified.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  2. ACCURACY OF INFORMATION\n' +
          '</p><p>\n' +
          '  The Company uses its commercially reasonable efforts to ensure that the information appearing on the pages of the Site are up-to-date and complete and contain no inaccuracies or errors. Despite all our efforts, some errors may occur and the Company will do everything possible to ensure these errors are corrected as soon as reasonably possible. The Company and its affiliates, directors, employees, officers, shareholders, agents, website designer and website provider (collectively the “<strong>Associates</strong>”) make no representation as to the completeness, accuracy or correctness of any information on the Site. &nbsp;\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  3. INTELLECTUAL PROPERTY\n' +
          '</p><p>\n' +
          '  All trademarks, trade dress, patents, copyrights and other intellectual property rights and materials, including images, text, illustrations, logos, designs, photographs, names, trade names, icons, programs, software and other materials that are part of this Site (collectively the “<strong>Content</strong>”), including but not limited to the arrangement, compilation, design and structure of such Content is subject to and protected by trademark, copyright and patent laws and is owned, controlled, licensed or, where required, used with permission by the Company.\n' +
          '</p><p>\n' +
          '  The Company and its suppliers and licensors expressly reserve all intellectual property rights in all content, products, processes, technology and other materials that appear on the Site. Access to the Site does not confer upon anyone any license under any of the Company’s and third party’s intellectual property rights, except to the extent required to access and make personal use of the Site.\n' +
          '</p><p>\n' +
          '  Certain trademarks, trade names and logos used or displayed on the Site are registered and unregistered trademarks or trade names of the Company or of its affiliates. Other trademarks, trade names and logos are registered and unregistered trademarks and trade name of their respective owners. No trademark or trade name license is granted in connection with the material contained on the Site. &nbsp;\n' +
          '</p><p>\n' +
          '  You may download copy and print selected portions of the Content and other downloadable materials displayed on this Site for your personal, non-commercial use only, and provided that you maintain all copyright and other notices contained on the Site or in the Content. Except as noted above, you are not authorized to use, reproduce, print, store, re-edit, change, download, sell or otherwise copy the Content or any other element of the Site, whether in whole or in part, for any other reason or for purposes of publication, dissemination or sale, on any medium or any format whatsoever. Be advised that the Company will fully enforce its intellectual property rights.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  4. DISCLAIMER\n' +
          '</p><p>\n' +
          '  THE FOLLOWING EXCLUSIONS OR LIMITATIONS DO NOT APPLY TO THE JURISDICTIONS WHERE THEY ARE PROHIBITED BY LAW. PLEASE REFER TO YOUR LOCAL LAWS FOR ANY SUCH PROHIBITIONS.\n' +
          '</p><p>\n' +
          '  YOU ACKNOWLEDGE, BY USING THE SITE THAT YOUR USE OF THIS SITE IS AT YOUR SOLE RISK. THE SITE IS PROVIDED BY THE COMPANY ON AN “AS IS” AND “AS AVAILABLE” BASIS. NEITHER THE COMPANY NOR ITS ASSOCIATES CAN ENSURE THAT ANY FILES OR OTHER DATA YOU DOWNLOAD FROM THE SITE WILL BE FREE OF VIRUSES, CONTAMINATION OR DESTRUCTIVE FEATURES. THE COMPANY AND ITS ASSOCIATES DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTIES OF ACCURACY, ACCESSIBILITY, MERCHANTABILITY, PERFORMANCE, DURABILITY AND FITNESS FOR A PARTICULAR PURPOSE. WITHOUT LIMITING THE GENERALITY OF THE FOREGOING, THE COMPANY AND ITS ASSOCIATES DISCLAIM ALL WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, FOR ANY MERCHANDISE OFFERED ON THE SITE. THIS DISCLAIMER CONSTITUTES AN ESSENTIAL PART OF THIS AGREEMENT. &nbsp;\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  5. LIMITATION OF LIABILITY\n' +
          '</p><p>\n' +
          '  THE FOLLOWING LIMITATIONS OF LIABILITY DO NOT APPLY TO THE JURISDICTION WHERE THEY ARE PROHIBITED BY LAW. PLEASE REFER TO YOUR LOCAL LAWS FOR ANY SUCH PROHIBITIONS.\n' +
          '</p><p>\n' +
          '  UNDER NO CIRCUMSTANCES AND UNDER NO LEGAL OR OTHER THEORY, WHETHER CONTRACTUAL, EXTRA-CONTRACTUAL, IN TORT, STRICT LIABILITY OR OTHERWISE, SHALL THE COMPANY OR ANY OF ITS ASSOCIATES BE LIABLE TO YOU OR ANY OTHER PERSON FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL, PUNITIVE OR EXEMPLARY LOSS OR DAMAGE ARISING FROM OR RELATING TO THE SITE OR THESE TERMS AND CONDITIONS, INCLUDING, WITHOUT LIMITATION, LOSS OF DATA, BUSINESS, PROFIT, SAVINGS, INCOME, USE, PRODUCTION, REPUTATION OR GOODWILL, REGARDLESS OF ANY NEGLIGENCE OR OTHER FAULT OR WRONGDOING BY THE COMPANY OR ANY PERSON FOR WHOM THE COMPANY IS RESPONSIBLE, AND EVEN IF THE COMPANY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH LOSS OR DAMAGE BEING INCURRED.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  6. INDEMNITY\n' +
          '</p><p>\n' +
          '  You agree to indemnify and hold the Company and its Associates harmless form any loss, liability, claims or expenses made against the Company or against any of its Associates and arising out of or in connection with your use of the Site.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  7. OTHER SITES\n' +
          '</p><p>\n' +
          '  This Site may contain links or references to other websites operated by other persons (the “<strong>Other Sites</strong>”). The Company is not responsible for and does not endorse the content of such Other Sites. Your use of the Other Sites is at your own risk and you will not make any claim against the Company or its Associates arising from, connected with or relating to your use of the Other Sites.\n' +
          '</p><p>\n' +
          '  Creating or maintaining any link from Other Sites to any page on this Site without the Company’s prior written permission is prohibited.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  8. DATA INTEGRITY\n' +
          '</p><p>\n' +
          '  You represent that all of the information, data and other materials you provide on this Site or to the Company through any other means are true, accurate, current and complete. You are responsible for correcting and updating the information you have provided on this Site, as appropriate.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  9. CONTENT YOU SUBMIT\n' +
          '</p><p>\n' +
          '  You acknowledge that you are responsible for any content you submit through the Site, including the legality, reliability and copyright of any such content. Without limiting the generality of the foregoing, you may not upload or otherwise publish to the Site any content that (i) may contain software viruses or malware, (ii) is confidential, proprietary, invasive of privacy, infringing on intellectual property, unlawful, harmful, false, fraudulent, threatening, defamatory, obscene, harassing, hateful, abusive or otherwise objectionable, including but not limited to any content that encourages conduct that would constitute a criminal offense or otherwise violate any applicable laws.\n' +
          '</p><p>\n' +
          '  You may not use a false email address or other identifying information, impersonate any person or entity or otherwise mislead as to the origin of any content. Some features that may be available on this Site require registration. By registering, you agree to provide true, accurate, current and complete information about yourself. You hereby represent, warrant and covenant that any content you provide does not include anything to which you do not have the full right to grant such a licence to the Company.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  10. SECURITY\n' +
          '</p><p>\n' +
          '  The Company is not responsible for any activities that occur under your account and password. The maintaining of the confidentiality of your account and password and the restricting of the access to your computer is your responsibility. You may use this Site only for lawful purposes.\n' +
          '</p><p>\n' +
          '  You are responsible for obtaining access to the Site and that access may involve third-party fees. You may not bypass any measures that have been implemented to prevent or restrict access to this Site. Any unauthorized access to the Site by you shall terminate the permission or license granted to you by the Company.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  11. TERMINATION OF USE\n' +
          '</p><p>\n' +
          '  The Company may, in its sole discretion, terminate your account or use of the Site at any time and without prior notice to you. To the extent this Site is a Transactional site, you are personally liable to the Company for any orders that you place or charges that you incur prior to such termination. The Company also reserves the right to change, suspend or permanently remove all or any content of the Site without prior notice.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  12. GOVERNING LAW; DISPUTE RESOLUTION\n' +
          '</p><p>\n' +
          '  The Terms and Conditions, your use of this Site and all related matters are governed solely by the laws of the <strong><u>state</u> </strong>of <strong><u>California </u></strong>and applicable federals laws of <strong><u>United States of America</u>.</strong>\n' +
          '</p><p>\n' +
          '  Any dispute between you and the Company or you and any other person arising from, connected with or relating to this Site, these Terms and Conditions or any related matters must be resolved before the Courts of <strong><u>California </u></strong>and you hereby irrevocably submit and attorn to the original and exclusive jurisdiction of those Courts in respect of any such dispute or matter.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  13. MISCELLANEOUS\n' +
          '</p><p>\n' +
          '  The non-enforcement of any provision hereof does not constitute a waiver of any right to enforce that provision in the future. These terms and conditions shall inure to the benefit of and be binding upon yourself, the Company and your respective successors and assigns.\n' +
          '</p><p>\n' +
          '  If any content on this Site, or your use of the Site, is contrary to the laws of the place where you are when you access it, the Site is not intended for you and we ask you not to use the Site.\n' +
          '</p><p>\n' +
          '  Except as otherwise expressly provided in these Terms and Conditions, there should be no third-party beneficiary to these Terms and Conditions.\n' +
          '</p><p>\n' +
          '  You may not assign the Terms and Conditions, in whole or in part, without the prior written consent of the Company, which may be withheld at the Company’s sole discretion. The Company may assign the Terms and Conditions, in whole or in part, to any third-party in its sole discretion.\n' +
          '</p><p>\n' +
          '  These Terms and Conditions constitute the entire agreement between you and the Company with respect to the subject matter hereof and supersede all prior or contemporaneous communications and proposals between the parties with respect to such subject matter.\n' +
          '</p><p style="margin-left:14.2pt;">\n' +
          '  14. CONTACT\n' +
          '</p><p>\n' +
          '  If you have any questions or comments about these Terms and Conditions or the Site, please contact us by email at:&nbsp;<em><strong><span style="background-color: rgba(0, 189, 255, 0.04); color: rgb(68, 68, 68); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; white-space: nowrap;">jeffpa@hillsflatlumber.com</span></strong></em>\n' +
          '</p><p>\n' +
          '  &nbsp;\n' +
          '</p></div>\n' +
          '\n' +
          '<div class="tb-wysiwyg-container"></div>\n' +
          '\n' +
          '</div>\n' +
          '</div>\n'
      };
    }
  };
</script>
