<template>
  <div class="order-container">
    <b-modal class="modal-box order-modal" ref="orderDialog">
      <div slot="modal-header">
        <h5>Order Details</h5>
      </div>

      <div class="d-block text-center" v-if="selectedOrder">
        <b-container class="bv-example-row">
          <b-row>
            <b-col class="left-side h-100">
              <b-card header="Order Summary" class="h-100">
                <b-card-text>
                  <div class="card-text-line">
                    <span>Status</span>
                    <p class="process"> {{selectedOrder.status}}</p>
                  </div>
                  <div class="card-text-line">
                    <span>Subtotal ({{selectedOrder.order_items_details.length}} {{selectedOrder.order_items_details.length > 1 ? 'items' : 'item'}})</span>
                    <p>${{selectedOrder.item_total}}</p>
                  </div>
                  <div class="card-text-line">
                    <span>Taxes</span>
                    <p>${{selectedOrder.tax_total}}</p>
                  </div>
                  <div class="card-text-line">
                    <h4><b>Total</b></h4>
                    <h3><b>${{selectedOrder.total}}</b></h3>
                  </div>
                  <div class="payment-method" style="display:none">
                    <b-card>
                      <div class="avtar-img">
                        <img src="/icons/illustration.png"/>
                      </div>
                      <b-card-text>
                        <div class="method">
                          <h5>Payment Method</h5>
                          <p>Credit Card</p>
                        </div>
                        <div class="method">
                          <h5>Credit Card</h5>
                          <p>**** **** **** 4923</p>
                        </div>
                        <div class="method">
                          <h5>Payment Status</h5>
                          <p>Processing</p>
                        </div>
                      </b-card-text>
                    </b-card>
                  </div>
                  <div class="payment-method" style="display:none">
                    <b-card>
                      <div class="avtar-img">
                        <img src="/icons/map.png" class="loader">
                      </div>
                      <b-card-text>
                        <div class="method">
                          <h5>Delivery</h5>
                          <p>Free Delivery</p>
                        </div>
                        <div class="method">
                          <h5>Credit Card</h5>
                          <p>**** **** **** 4923</p>
                        </div>
                        <div class="method">
                          <h5>Deliver To</h5>
                          <p>19040 Soledad Canyon St, Suite 230<br/>
                            Santa Clarita, CA - California 91351</p>
                        </div>
                        <div class="method">
                          <h5>Delivery Status</h5>
                          <p>Waiting Payment</p>
                        </div>
                      </b-card-text>
                    </b-card>
                  </div>
                </b-card-text>
              </b-card>
            </b-col>
            <b-col class="right-side h-100">
              <b-card header="Products" class="h-100">
                <b-card-text>
                  <div class="product">
                    <div class="product-table" v-for="product in selectedOrder.order_items_details" :key="product.id">
                      <img :src="product.image_url" class="image-box"/>
                      <p>{{product.title}}</p>
                      <h6>{{product.quantity}}</h6>
                      <h5>${{product.line_price}}</h5>
                    </div>
                  </div>
                </b-card-text>
                <div class="d-flex justify-content-end align-items-end">
                  <b-button @click="hideDialog" class="btn-primary">Done</b-button>
                </div>
              </b-card>
            </b-col>
          </b-row>
        </b-container>
      </div>

      <div slot="modal-footer"/>
    </b-modal>

    <h4>My Orders</h4>
    <template v-if="!orders">
      <div class="page-loader">
        <img src="/icons/loader.gif" class="loader"/>
      </div>
    </template>
    <template v-else-if="orders.length === 0">
      <span>No orders found.</span>
    </template>
    <template v-else>
      <b-table
        :items="orders"
        :fields="fields" responsive>
        <template slot="actions" slot-scope="row">
          <a href="#" @click.prevent="viewOrder(row.item)">View Order</a>
        </template>
      </b-table>
    </template>


  </div>
</template>
<script>
  import OrderApiService from '@/api-services/order.service';

  export default {
    data() {
      return {
        orders: null,
        selectedOrder: null,
        orderType: ['Pick up in store', 'Delivery', 'Shipping'],
        items: [
          {id: "10030145245", date: '05/23/2018', shipTo: 'Lawrence Mansour', total: '$43.75', status: 'Completed'},
          {id: "10030145245", date: '05/23/2018', shipTo: 'Lawrence Mansour', total: '$43.75', status: 'Completed'},
          {id: "10030145245", date: '05/23/2018', shipTo: 'Lawrence Mansour', total: '$43.75', status: 'Completed'},
          {id: "10030145245", date: '05/23/2018', shipTo: 'Lawrence Mansour', total: '$43.75', status: 'Completed'}
        ],
        fields: [
          {key: "id", label: "Order #"},
          {key: "date", label: "Date"},
          {key: "shipTo", label: "Ship To"},
          {key: "total", label: "Total"},
          {key: "status", label: "Status"},
          {key: "actions", label: ""}
        ]
      };
    },
    async mounted() {
      let response = await OrderApiService.getOrders();
      response = response.data.data;
      const orders = response.data;
      this.orders = orders.map(order => {
        return {
          id: order.id,
          date: new Date(order.createdAt).toLocaleDateString(),
          shipTo: response.customer_details.first_name + ' ' + response.customer_details.last_name,
          total: '$' + order.total_price,
          status: order.status
        };
      });
    },
    methods: {
      async viewOrder(order) {
        const response = await OrderApiService.getOrderDetails(order.id);
        this.selectedOrder = response.data.data;
        this.$refs.orderDialog.show();
      },
      hideDialog() {
        this.$refs.orderDialog.hide();
      }
    }
  };
</script>
<style lang="scss">
  .order-container {
    h4 {
      font-size: 20px;
      line-height: 23px;
      color: #181C20;
      padding: 18px 0;

    }

    table {
      width: 100%;

      thead {
        margin-top: 25px;
        line-height: 25px;
        border-bottom: 1px solid #EAEAEB;

        tr {
          th {
            font-weight: 600;
            font-size: 14px;
            line-height: 24px;
            color: #181C20;

          }
        }
      }

      tbody {
        tr {
          td {
            font-weight: 400;
            font-size: 14px;
            line-height: 24px;
            color: #181C20;
            border-bottom: 1px solid #EAEAEB;

            &:nth-of-type(5) {
              font-style: italic;
            }

            &:last-child {
              cursor: pointer;
              color: #A02230;
            }
          }
        }
      }
    }

    .modal-box {
      .modal-dialog {
        max-width: 1140px !important;

        .modal-header {

          background: transparent;

          div {
            color: #000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;

            h5 {
              margin-bottom: 0;
            }

            span {
              width: 20px;
              height: 20px;
              background: #A02230;
              border-radius: 50%;
              display: flex;
              justify-content: center;
              align-items: center;
              color: #fff;
              cursor: pointer;
            }
          }

        }

        .modal-footer {
          display: none;
        }
      }
    }
  }

  .left-side {
    .card {
      .card-header {
        background: transparent;
        display: flex;
      }
    }

    .card-text {
      .card-text-line {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #EAEAEB;

        span {
          font-weight: 500;
          font-size: 14px;
          line-height: 36px;
          color: #ACACAC;
        }

        .process {
          font-size: 14px;
          line-height: 36px;
          text-align: right;
          color: #4A90E2;
        }

        p {
          font-size: 14px;
          line-height: 16px;
          color: #181C20;
          margin: 0;
        }

        h4 {
          font-weight: 500;
          font-size: 18px;
          line-height: 21px;
          color: #181C20;
          margin: 0;
        }

        h3 {
          font-size: 18px;
          line-height: 21px; /* identical to box height */
          font-weight: 600;
          color: #181C20;
          margin: 0;
        }
      }

      .payment-method {
        margin-top: 20px;

        .avtar-img {
          padding-right: 15px;
        }

        .card {
          .card-header {
            background: transparent;
            display: flex;
          }

          .card-body {
            display: flex;
            align-items: flex-start;

            .card-text {
              flex: 1;

              .method {
                display: flex;
                justify-content: space-between;
                align-items: center;

                h5 {
                  font-weight: 500;
                  font-size: 14px;
                  line-height: 16px;
                  color: #ACACAC;
                }

                p {
                  font-size: 14px;
                  line-height: 16px;
                  color: #181C20;
                  font-weight: 400;
                }
              }
            }
          }
        }
      }


    }
  }


  .right-side {
    .card {
      .card-header {
        background: transparent;
        display: flex;
      }
    }
    position: relative;
    .product {
      .product-table {
        display: flex;
        justify-content: center;
        border-bottom: 1px solid #EAEAEB;;
        margin: 5px 0 15px;
        max-height: 90px;
        padding-bottom: 10px;
        align-items: center;
        &:last-child {
          border-bottom: none;
        }
        .image-box {
          flex: 1;
          width: 100%;
          height: auto;
          max-width: 64px;
          max-height: 64px;
          margin-right: 15px;
        }
        p {
          flex: 3;
          font-weight: normal;
          font-size: 14px;
          line-height: 20px; /* or 140% */
          color: #181C20;
          display: flex;
          text-align: left;
          margin-bottom: 0;
        }

        h5 {
          flex: 1;
          margin-bottom: 0;
        }

        h6 {
          margin-bottom: 0;
          flex: 0.5;
          font-size: 16px;
          line-height: 30px;
          text-align: center;
          color: #181C20;
        }
      }
    }

    .button-done {
      position: absolute;
      bottom: 0;
      right: 15px;

      button {
        background: #A02230;
        border: none;
      }
    }
  }

  @media (max-width: 767px) {
    .payment-method {
      .card {
        .card-body {
          display: flex;
          align-items: center;
          flex-direction: column;
        }
      }
    }
    .right-side {
      margin: 30px 0;

      .product {
        .product-table {
          p {
            text-overflow: ellipsis;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            height: 56px;
          }
        }
      }
    }
    .left-side {
      .card-text {
        .payment-method {
          .card {
            .card-body {
              display: flex;
              align-items: stretch;

              .card-text {
                .method {
                  p {
                    text-overflow: ellipsis;
                    overflow: hidden;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    width: 120px;
                    -webkit-line-clamp: 2;
                    text-align: right;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
</style>
