<template>
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-3">
        <b-nav vertical>
          <b-nav-text>
            <router-link :to="{ name: 'settings-account' }">Account Information</router-link>
          </b-nav-text>
          <b-nav-text>
            <router-link :to="{ name: 'settings-orders' }">My Orders</router-link>
          </b-nav-text>
          <!-- <b-nav-text>
            <router-link :to="{ name: 'settings-payment' }">Payment methods</router-link>
          </b-nav-text> -->
          <b-nav-text class="cursor-pointer">
            <a @click="logout" href="#">Logout</a>
          </b-nav-text>
        </b-nav>
      </div>
      <div class="col-md-9 pt-0">
        <router-view/>
      </div>
    </div>
  </div>
</template>

<script>
import AuthApiService from '@/api-services/auth.service';
import AuthController from '@/controllers/auth.controller';

export default {
  name: 'SettingsParentPage',
  methods: {
      logout() {
          AuthApiService.logout()
          .then(res => {
            if(res.data.status == "success") {
              this.$swal({
                toast: true,
                position: 'top',
                showConfirmButton: false,
                timer: 3000,
                type: 'success',
                title: 'signed out'
              });
            } else {
              this.$swal(res.data.message, '', 'error');
            }
          })
          .catch(err => {
            console.log(err);
            this.$swal('Unknown error while loggin out', '', 'error');
          });
          AuthController.logout();
          this.$store.dispatch('logout');
          this.$router.push({ name: 'index' });
      },
  },
};
</script>

<style lang="scss">
@import '@/assets/scss/settings.scss';
</style>

<style lang="scss" scoped>
.container {
  border: 1px solid #eaeaeb;
  border-radius: 5px;

  .row > div {
    padding: 20px;

    &:first-child {
      border-right: 1px solid #eaeaeb;
    }
  }
}
</style>

