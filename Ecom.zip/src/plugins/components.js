import Vue from 'vue';
import DefaultLayout from '@/layouts/default.vue';
import EmptyLayout from '@/layouts/empty.vue';
import SecondaryLayout from '@/layouts/secondary.vue';
import AdminLayout from '@/layouts/admin.vue';
import Header from '@/components/header-black.vue';
import ProductItem from '@/components/product-item.vue';
import BrandItem from '@/components/brand-item.vue';
import MediaItem from '@/components/media-item.vue';
import ChangeQuantity from '@/components/change-quantity.vue';
import SubscribeSection from '@/components/sections/subscribe-section.vue';
import CarouselSection from '@/components/sections/carousel-section.vue';
import DepartmentsSection from '@/components/sections/departments-section.vue';
import FavouriteProductsSection from '@/components/sections/favourite-products-section.vue';

import AuthWithEmail from '@/components/auth/email.vue';
import AuthWithPhone from '@/components/auth/phone.vue';
import VideoLightbox from '@/components/video-lightbox.vue';
import DepartmentSlider from '@/components/departments/department-slider.vue';
import DepartmentCategory from '@/components/departments/department-category.vue';
import CartMember from '@/components/cart/cart-member.vue';
import CartPayment from '@/components/cart/cart-payment.vue';

import MainHeader from '@/components/admin/main-header.vue';
import SiteHeader from '@/components/admin/site-header.vue';
import AdminCarouselSection from '@/components/admin/sections/carousel-section.vue';
import AdminDepartmentsSection from '@/components/admin/sections/departments-section.vue';
import AdminSubscribeSection from '@/components/admin/sections/subscribe-section.vue';
import Connect  from '@/components/connect.vue';

Vue.component ('default-layout', DefaultLayout);
Vue.component ('empty-layout', EmptyLayout);
Vue.component ('secondary-layout', SecondaryLayout);
Vue.component('admin-layout', AdminLayout);
Vue.component ('header-black', Header);
Vue.component('social-connect', Connect);
Vue.component ('carousel-section', CarouselSection);
Vue.component ('subscribe-section', SubscribeSection);
Vue.component ('departments-section', DepartmentsSection);
Vue.component ('favourite-products-section', FavouriteProductsSection);

Vue.component ('product-item', ProductItem);
Vue.component ('brand-item', BrandItem);
Vue.component ('media-item', MediaItem);
Vue.component ('change-quantity', ChangeQuantity);

Vue.component ('auth-with-email', AuthWithEmail);
Vue.component ('auth-with-phone', AuthWithPhone);
Vue.component ('video-lightbox', VideoLightbox);
Vue.component ('department-slider', DepartmentSlider);
Vue.component ('department-category', DepartmentCategory);
Vue.component('cart-member', CartMember);
Vue.component('cart-payment', CartPayment);

Vue.component('main-header', MainHeader);
Vue.component('site-header', SiteHeader);
Vue.component('admin-carousel-section', AdminCarouselSection);
Vue.component('admin-departments-section', AdminDepartmentsSection);
Vue.component('admin-subscribe-section', AdminSubscribeSection);
