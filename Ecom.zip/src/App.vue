<template>
  <div id="app">
    <default-layout v-if="layout === 'default'">
      <router-view :key="$route.fullPath" />
    </default-layout>

    <secondary-layout v-if="layout === 'secondary'">
      <router-view/>
    </secondary-layout>

    <empty-layout v-if="layout === 'empty'">
      <router-view/>
    </empty-layout>

    <admin-layout v-if="layout === 'admin'">
      <router-view />
    </admin-layout>

  </div>
</template>

<script>
  export default {
    name: 'App',
    data: () => ({
      layout: 'default',
    }),
    mounted() {
        const chosenStore = localStorage.getItem("selectedStore");
        if ( !chosenStore ) {
            this.$refs.storeSelectionModal.showModal();
        }
    },
    watch: {
      '$route': function (to, from) {
        if (to.name === 'products-id') {
          localStorage.setItem('product_breadcrumbs', JSON.stringify({
            from: from.name || 'index',
            fullPath: from.fullPath,
            params: from.params
          }));
        }
        let meta = this.$route.meta;

        this.layout = meta.layout ? meta.layout : 'default';
      }
    },
  };
</script>

<style lang="scss">
@import '@/assets/scss/app.scss';
</style>
